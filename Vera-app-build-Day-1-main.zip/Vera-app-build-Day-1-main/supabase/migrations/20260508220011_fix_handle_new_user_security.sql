/*
  # Fix handle_new_user function security

  1. Changes
    - Set a fixed search_path on handle_new_user to prevent mutable search_path vulnerability
    - Revoke EXECUTE on handle_new_user from anon and authenticated roles
      (it is a trigger function and should never be called directly via RPC)
*/

ALTER FUNCTION public.handle_new_user()
  SET search_path = public, pg_temp;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;
