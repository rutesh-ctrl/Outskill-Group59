/*
  # Auto-create user profile on signup

  1. New Function
    - `public.handle_new_user()` — trigger function that inserts a row
      into `user_profiles` whenever a new user is created in `auth.users`.
      This ensures OAuth users (Google) get a profile row automatically,
      since they bypass the email/password signup flow that normally
      creates the profile via the onboarding screens.

  2. New Trigger
    - `on_auth_user_created` — AFTER INSERT on `auth.users` calls
      `handle_new_user()`.

  3. Security
    - The function runs with SECURITY DEFINER (as the database owner)
      so it can insert into `user_profiles` regardless of RLS policies.
    - The trigger fires automatically — no client-side code needed.
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.user_profiles (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
