/*
  # Create user_goals table for multiple goals per user

  ## Summary
  Replaces the single `goal` + `savings_goal_amount` columns on user_profiles
  with a proper `user_goals` table so users can track multiple concurrent goals.

  ## New Tables
  - `user_goals`
    - `id` (uuid, pk)
    - `user_id` (uuid, fk → auth.users)
    - `goal_type` (text) — one of: save_more, spend_less, clear_debt, understand, feel_less_anxious
    - `label` (text) — human-readable label
    - `target_amount` (numeric, nullable) — monetary target if applicable
    - `current_amount` (numeric) — manually updated progress (default 0)
    - `is_active` (boolean) — soft-delete / archive
    - `created_at` (timestamptz)

  ## Security
  - RLS enabled
  - Authenticated users can only access their own goals
*/

CREATE TABLE IF NOT EXISTS user_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  goal_type text NOT NULL DEFAULT '',
  label text NOT NULL DEFAULT '',
  target_amount numeric(12,2) DEFAULT NULL,
  current_amount numeric(12,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own goals"
  ON user_goals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own goals"
  ON user_goals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own goals"
  ON user_goals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own goals"
  ON user_goals FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_user_goals_user_id ON user_goals(user_id);
CREATE INDEX IF NOT EXISTS idx_user_goals_active ON user_goals(user_id, is_active);
