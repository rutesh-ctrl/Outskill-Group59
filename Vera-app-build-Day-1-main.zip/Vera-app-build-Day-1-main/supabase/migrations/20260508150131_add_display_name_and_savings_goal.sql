/*
  # Add display_name and savings_goal_amount to user_profiles

  ## Changes
  - `display_name` (text, nullable) — user's first name shown in greeting
  - `savings_goal_amount` (numeric, nullable) — target amount for the goal tracker on Home screen
    Used alongside the existing `goal` field: if goal is 'save_more' or 'clear_debt',
    this stores the target number (e.g. save £5000, clear £3200 of debt).
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'display_name'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN display_name text DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'savings_goal_amount'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN savings_goal_amount numeric(12,2) DEFAULT NULL;
  END IF;
END $$;
