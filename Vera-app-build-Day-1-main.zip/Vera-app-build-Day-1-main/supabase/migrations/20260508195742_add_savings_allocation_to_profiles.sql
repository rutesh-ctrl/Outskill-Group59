/*
  # Add savings_allocation to user_profiles

  ## Summary
  Adds a column to track how the user wants to allocate their end-of-month
  savings surplus: either apply it towards clearing debt, or keep it as savings.

  ## Changes
  - `user_profiles`
    - `savings_allocation` (text): one of 'apply_to_debt' | 'keep_as_savings' | null (not yet answered)
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'savings_allocation'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN savings_allocation text DEFAULT NULL;
  END IF;
END $$;
