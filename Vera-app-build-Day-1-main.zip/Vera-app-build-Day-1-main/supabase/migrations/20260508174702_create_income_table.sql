/*
  # Create income table

  ## Summary
  Adds a dedicated income table so users can log individual income entries
  (salary, freelance, transfers, etc.) separate from the monthly_income field
  on user_profiles which represents a budget estimate.

  ## New Tables
  - `income`
    - `id` (uuid, primary key)
    - `user_id` (uuid, FK → auth.users)
    - `amount` (numeric, required)
    - `currency_code` (text, default 'GBP')
    - `description` (text, brief label for the income)
    - `category` (text, e.g. Salary, Freelance, Gift, Investment, Other)
    - `income_date` (date, defaults to today)
    - `created_at` (timestamptz)

  ## Security
  - RLS enabled
  - Users can only SELECT, INSERT, UPDATE, DELETE their own rows
*/

CREATE TABLE IF NOT EXISTS income (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount        numeric NOT NULL,
  currency_code text NOT NULL DEFAULT 'GBP',
  description   text NOT NULL DEFAULT '',
  category      text NOT NULL DEFAULT 'Other',
  income_date   date NOT NULL DEFAULT CURRENT_DATE,
  created_at    timestamptz DEFAULT now()
);

ALTER TABLE income ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can select own income"
  ON income FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own income"
  ON income FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own income"
  ON income FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own income"
  ON income FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS income_user_id_date_idx ON income(user_id, income_date DESC);
