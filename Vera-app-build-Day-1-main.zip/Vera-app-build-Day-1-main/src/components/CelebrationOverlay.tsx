import { useEffect, useRef, useCallback } from 'react';
import { UserGoal } from '../lib/types';

// ─── Personalised messages per goal type ──────────────────────────────────────
const GOAL_MESSAGES: Record<string, { headline: string; sub: string }> = {
  save_more:           { headline: 'Savings target reached!',         sub: 'Your hard work is paying off. Keep building that buffer.' },
  spend_less:          { headline: 'Monthly spend target crushed!',    sub: "You stayed under budget this month — that's real discipline." },
  clear_debt:          { headline: 'Debt payoff milestone hit!',       sub: "One step closer to financial freedom. You're doing it." },
  understand:          { headline: 'Awareness goal unlocked!',         sub: "You've been tracking consistently — knowledge is power." },
  feel_less_anxious:   { headline: 'Comfort budget on track!',         sub: "You stayed within your comfort zone. Control feels good." },
};

const FALLBACK_MESSAGE = { headline: 'Goal reached!', sub: "Brilliant — you hit your target. Keep going!" };

// ─── Confetti particle config ──────────────────────────────────────────────────
const COLORS = ['#0D9B8A', '#22C997', '#4A7FC1', '#F5A623', '#E8495A', '#0F2D5C', '#F8F9FC'];
const PARTICLE_COUNT = 120;

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  rotSpeed: number;
  w: number;
  h: number;
  color: string;
  opacity: number;
}

// ─── Web Audio chime ────────────────────────────────────────────────────────────
function playChime() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = ctx.currentTime + i * 0.12;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.18, start + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.55);
      osc.start(start);
      osc.stop(start + 0.6);
    });
  } catch {
    // Audio not available — silent fallback
  }
}

// ─── Component ─────────────────────────────────────────────────────────────────
interface CelebrationOverlayProps {
  goal: UserGoal;
  onDismiss: () => void;
}

export default function CelebrationOverlay({ goal, onDismiss }: CelebrationOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const rafRef = useRef<number>(0);
  const startTimeRef = useRef<number>(0);
  const DURATION = 4500; // ms

  const msg = GOAL_MESSAGES[goal.goal_type] ?? FALLBACK_MESSAGE;

  const initParticles = useCallback(() => {
    const W = window.innerWidth;
    particlesRef.current = Array.from({ length: PARTICLE_COUNT }, () => ({
      x: Math.random() * W,
      y: -20 - Math.random() * 80,
      vx: (Math.random() - 0.5) * 3,
      vy: 2 + Math.random() * 4,
      rot: Math.random() * 360,
      rotSpeed: (Math.random() - 0.5) * 8,
      w: 8 + Math.random() * 8,
      h: 4 + Math.random() * 6,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      opacity: 0.85 + Math.random() * 0.15,
    }));
  }, []);

  const animate = useCallback((ts: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (!startTimeRef.current) startTimeRef.current = ts;
    const elapsed = ts - startTimeRef.current;
    const fadeStart = DURATION * 0.65;
    const globalOpacity = elapsed > fadeStart
      ? Math.max(0, 1 - (elapsed - fadeStart) / (DURATION - fadeStart))
      : 1;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    particlesRef.current.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.06; // gravity
      p.vx *= 0.995;
      p.rot += p.rotSpeed;

      if (p.y > canvas.height + 20) {
        p.y = -20;
        p.x = Math.random() * canvas.width;
        p.vy = 2 + Math.random() * 3;
      }

      ctx.save();
      ctx.globalAlpha = p.opacity * globalOpacity;
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rot * Math.PI) / 180);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    });

    if (elapsed < DURATION) {
      rafRef.current = requestAnimationFrame(animate);
    } else {
      onDismiss();
    }
  }, [onDismiss]);

  useEffect(() => {
    initParticles();
    playChime();
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [initParticles, animate]);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      onClick={onDismiss}
    >
      {/* Confetti canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ width: '100%', height: '100%' }}
      />

      {/* Semi-transparent backdrop */}
      <div className="absolute inset-0 bg-navy/50 backdrop-blur-[2px]" />

      {/* Modal card */}
      <div
        className="relative z-10 mx-5 bg-white rounded-[24px] shadow-2xl px-8 py-10 flex flex-col items-center text-center max-w-sm w-full animate-celebration-pop"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Trophy emoji */}
        <div className="w-20 h-20 rounded-full bg-teal/10 flex items-center justify-center mb-5 text-[40px] leading-none select-none">
          🎉
        </div>

        <h2 className="font-heading font-bold text-navy text-[24px] leading-tight mb-2">
          You did it!
        </h2>
        <p className="font-heading font-semibold text-teal text-[17px] mb-3 leading-snug">
          {msg.headline}
        </p>
        <p className="font-sans text-[14px] text-slate leading-relaxed mb-8">
          {msg.sub}
        </p>

        <button
          onClick={onDismiss}
          className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-semibold font-sans hover:bg-opacity-90 active:scale-95 transition-all"
        >
          Back to dashboard
        </button>
        <p className="font-sans text-[12px] text-muted mt-3">Tap anywhere to dismiss</p>
      </div>
    </div>
  );
}
