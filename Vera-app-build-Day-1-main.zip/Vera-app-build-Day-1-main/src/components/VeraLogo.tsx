interface VeraLogoProps {
  size?: number;
  className?: string;
  iconOnly?: boolean;
}

export default function VeraLogo({ size = 56, className = '', iconOnly = false }: VeraLogoProps) {
  const w = size;
  // Icon-only: square. Full: extra 70px for wordmark + tagline (proportional to 200px icon)
  const h = iconOnly ? size : Math.round(size * (280 / 200));

  return (
    <svg
      width={w}
      height={h}
      viewBox={iconOnly ? '0 0 200 200' : '0 0 200 280'}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="vl-left" x1="30" y1="30" x2="100" y2="175" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#7C3AED" />
          <stop offset="100%" stopColor="#1E3A5F" />
        </linearGradient>
        <linearGradient id="vl-right" x1="100" y1="30" x2="130" y2="160" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#2DD4BF" />
          <stop offset="100%" stopColor="#0D9B8A" />
        </linearGradient>
      </defs>

      {/* Icon square */}
      <rect x="0" y="0" width="200" height="200" rx="40" ry="40" fill="#FAF7F2" />

      {/* Left arm of V — purple → navy */}
      <polygon points="22,25  52,25  102,158  72,158" fill="url(#vl-left)" />

      {/* Right arm of V — teal (lower leg) */}
      <polygon points="72,158  102,158  118,110  88,110" fill="url(#vl-right)" />
      {/* Right arm of V — teal (upper sweep) */}
      <polygon points="88,110  118,110  148,28  118,28" fill="url(#vl-right)" />

      {/* Bar chart — 3 ascending bars */}
      <rect x="108" y="118" width="14" height="36" rx="4" fill="url(#vl-right)" />
      <rect x="126" y="104" width="14" height="50" rx="4" fill="url(#vl-right)" />
      <rect x="144" y="88"  width="14" height="66" rx="4" fill="url(#vl-right)" />

      {/* Dollar coin */}
      <circle cx="122" cy="165" r="18" fill="url(#vl-right)" />
      <text
        x="122"
        y="171"
        textAnchor="middle"
        fill="white"
        fontSize="18"
        fontWeight="700"
        fontFamily="system-ui, sans-serif"
      >$</text>

      {/* Wordmark + tagline — only when not icon-only */}
      {!iconOnly && (
        <>
          <text
            x="100"
            y="232"
            textAnchor="middle"
            fill="#0F2D5C"
            fontSize="28"
            fontWeight="800"
            fontFamily="'DM Sans', 'Inter', system-ui, sans-serif"
            letterSpacing="6"
          >VERA</text>
          <text
            x="100"
            y="258"
            textAnchor="middle"
            fill="#0F2D5C"
            fontSize="11.5"
            fontWeight="400"
            fontFamily="'Inter', system-ui, sans-serif"
            letterSpacing="0.3"
            opacity="0.65"
          >Your AI financial mentor.</text>
        </>
      )}
    </svg>
  );
}
