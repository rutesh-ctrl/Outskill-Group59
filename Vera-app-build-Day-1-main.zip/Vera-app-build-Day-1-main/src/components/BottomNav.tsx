import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, BarChart2, Plus, BookOpen, Settings, X, TrendingDown, TrendingUp, CreditCard, type LucideIcon } from 'lucide-react';

interface NavTab {
  label: string;
  icon: LucideIcon;
  to: string;
  primary?: boolean;
}

const TABS: NavTab[] = [
  { label: 'Home', icon: Home, to: '/' },
  { label: 'Insights', icon: BarChart2, to: '/dashboard' },
  { label: 'Add', icon: Plus, to: '/add', primary: true },
  { label: 'Learn', icon: BookOpen, to: '/learn' },
  { label: 'Settings', icon: Settings, to: '/settings' },
];

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname;
  const [showPicker, setShowPicker] = useState(false);

  const isActive = (to: string) => {
    if (to === '/') return path === '/';
    return path.startsWith(to);
  };

  return (
    <>
      {showPicker && (
        <div
          className="fixed inset-0 z-30 bg-navy/30 backdrop-blur-sm"
          onClick={() => setShowPicker(false)}
        />
      )}

      {showPicker && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-2rem)] max-w-sm animate-slide-up">
          <div className="bg-surface rounded-[20px] shadow-2xl overflow-hidden border border-border">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <p className="font-heading font-semibold text-navy text-[16px]">What would you like to add?</p>
              <button
                onClick={() => setShowPicker(false)}
                className="p-1.5 rounded-btn text-muted hover:text-slate transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-3 space-y-2">
              <button
                onClick={() => { setShowPicker(false); navigate('/add'); }}
                className="w-full flex items-center gap-4 p-4 rounded-[14px] bg-red/5 border border-red/15 hover:bg-red/10 active:scale-[0.98] transition-all text-left"
              >
                <div className="w-11 h-11 rounded-full bg-red/10 flex items-center justify-center shrink-0">
                  <TrendingDown size={20} className="text-red" />
                </div>
                <div>
                  <p className="font-sans font-semibold text-[15px] text-navy">Add Expense</p>
                  <p className="font-sans text-[12px] text-muted mt-0.5">Log what you've spent</p>
                </div>
              </button>

              <button
                onClick={() => { setShowPicker(false); navigate('/income'); }}
                className="w-full flex items-center gap-4 p-4 rounded-[14px] bg-teal/5 border border-teal/15 hover:bg-teal/10 active:scale-[0.98] transition-all text-left"
              >
                <div className="w-11 h-11 rounded-full bg-teal/10 flex items-center justify-center shrink-0">
                  <TrendingUp size={20} className="text-teal" />
                </div>
                <div>
                  <p className="font-sans font-semibold text-[15px] text-navy">Add Income</p>
                  <p className="font-sans text-[12px] text-muted mt-0.5">Record money coming in</p>
                </div>
              </button>

              <button
                onClick={() => { setShowPicker(false); navigate('/debt-payment'); }}
                className="w-full flex items-center gap-4 p-4 rounded-[14px] bg-navy/5 border border-navy/15 hover:bg-navy/10 active:scale-[0.98] transition-all text-left"
              >
                <div className="w-11 h-11 rounded-full bg-navy/10 flex items-center justify-center shrink-0">
                  <CreditCard size={20} className="text-navy" />
                </div>
                <div>
                  <p className="font-sans font-semibold text-[15px] text-navy">Debt Payment</p>
                  <p className="font-sans text-[12px] text-muted mt-0.5">Pay off outstanding debt</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-surface border-t border-border">
        <div className="max-w-lg mx-auto px-1 h-16 flex items-center">
          {TABS.map((tab) => {
            if (tab.primary) {
              return (
                <div key={tab.to} className="flex-1 flex justify-center">
                  <button
                    onClick={() => setShowPicker((v) => !v)}
                    aria-label="Add"
                    className={`flex flex-col items-center justify-center w-14 h-14 -mt-6 rounded-full text-white shadow-[0_4px_16px_rgba(13,155,138,0.4)] transition-all active:scale-95 ${
                      showPicker ? 'bg-navy rotate-45' : 'bg-teal hover:bg-opacity-90'
                    }`}
                    style={{ transition: 'background-color 0.2s ease, transform 0.2s ease' }}
                  >
                    <tab.icon size={22} strokeWidth={2.5} />
                  </button>
                </div>
              );
            }

            const active = isActive(tab.to);
            return (
              <button
                key={tab.to}
                onClick={() => { setShowPicker(false); navigate(tab.to); }}
                aria-label={tab.label}
                className={`flex-1 flex flex-col items-center justify-center gap-0.5 h-full py-2 transition-colors min-h-[44px] ${
                  active ? 'text-teal' : 'text-muted hover:text-slate'
                }`}
              >
                <tab.icon size={20} />
                <span className={`font-sans text-[10px] font-medium leading-none ${active ? 'text-teal' : 'text-muted'}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}