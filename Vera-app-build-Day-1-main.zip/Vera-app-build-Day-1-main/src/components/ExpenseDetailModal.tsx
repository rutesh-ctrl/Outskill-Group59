import { useEffect, useState } from 'react';
import { X, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Expense, Category, CATEGORIES } from '../lib/types';
import { formatAmount, formatDate } from '../lib/currency';
import { useAuth } from '../context/AuthContext';

interface Props {
  expenseId: string;
  currencyCode: string;
  onClose: () => void;
  onUpdate: () => void;
}

export default function ExpenseDetailModal({ expenseId, currencyCode, onClose, onUpdate }: Props) {
  const { profile } = useAuth();
  const [expense, setExpense] = useState<Expense | null>(null);
  const [category, setCategory] = useState<Category>('Other');
  const [isEssential, setIsEssential] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('expenses')
        .select('*')
        .eq('id', expenseId)
        .maybeSingle();
      if (data) {
        setExpense(data as Expense);
        setCategory(data.category as Category);
        setIsEssential(data.is_essential);
      }
      setLoading(false);
    };
    fetch();
  }, [expenseId]);

  const handleSave = async () => {
    if (!expense) return;
    setSaving(true);
    setError('');
    try {
      const { error: updateError } = await supabase
        .from('expenses')
        .update({ category, is_essential: isEssential })
        .eq('id', expense.id);
      if (updateError) throw updateError;
      onUpdate();
      onClose();
    } catch {
      setError('Could not save changes — please try again');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!expense) return;
    setDeleting(true);
    try {
      const { error: deleteError } = await supabase.from('expenses').delete().eq('id', expense.id);
      if (deleteError) throw deleteError;
      onUpdate();
      onClose();
    } catch {
      setError('Could not delete expense — please try again');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-navy/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="relative bg-surface w-full max-w-lg rounded-t-card sm:rounded-card shadow-xl p-6 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading font-semibold text-navy text-[18px]">Expense detail</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-btn text-muted hover:text-slate hover:bg-border/50 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {loading ? (
          <div className="space-y-4">
            <div className="h-8 bg-border rounded animate-pulse w-1/2" />
            <div className="h-5 bg-border rounded animate-pulse w-1/3" />
            <div className="h-12 bg-border rounded animate-pulse w-full" />
          </div>
        ) : expense ? (
          <div className="space-y-5">
            {/* Amount & description */}
            <div>
              <p
                className="font-sans font-semibold text-navy text-[28px] leading-none"
                style={{ fontVariantNumeric: 'tabular-nums' }}
              >
                {formatAmount(expense.amount, expense.currency_code || currencyCode)}
              </p>
              <p className="font-heading font-semibold text-[16px] text-slate mt-1.5">{expense.description}</p>
              <p className="text-[13px] text-muted font-sans mt-1">{formatDate(expense.expense_date)}</p>
            </div>

            {/* Category */}
            <div>
              <label className="block text-[13px] font-medium text-slate mb-2">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full h-12 px-4 border border-border rounded-input text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Essential toggle */}
            <button
              onClick={() => setIsEssential((v) => !v)}
              className="flex items-center gap-3 w-full py-3 border-t border-b border-border"
            >
              {isEssential ? (
                <ToggleRight size={24} className="text-teal" />
              ) : (
                <ToggleLeft size={24} className="text-muted" />
              )}
              <div className="text-left">
                <p className="font-sans font-medium text-[14px] text-slate">
                  {isEssential ? 'Essential' : 'Avoidable'}
                </p>
                <p className="font-sans text-[12px] text-muted">Tap to toggle</p>
              </div>
            </button>

            {/* Micro-reaction */}
            {expense.micro_reaction && (
              <div className="p-4 bg-ai-bg border-l-[3px] border-teal rounded-r-btn">
                <p className="text-[11px] uppercase tracking-widest text-muted font-sans mb-1.5">{profile?.display_name || 'Vera'}</p>
                <p className="font-heading italic text-[14px] text-slate leading-relaxed">
                  {expense.micro_reaction}
                </p>
              </div>
            )}

            {error && (
              <p className="text-[13px] text-red font-sans">{error}</p>
            )}

            {/* Confirm delete dialog */}
            {confirmDelete ? (
              <div className="p-4 bg-red/5 border border-red/30 rounded-btn">
                <p className="font-sans font-medium text-[14px] text-slate mb-3">Delete this expense?</p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setConfirmDelete(false)}
                    className="flex-1 h-10 border border-border rounded-btn text-[14px] font-medium text-slate font-sans hover:bg-page transition-colors"
                  >
                    Keep it
                  </button>
                  <button
                    onClick={handleDelete}
                    disabled={deleting}
                    className="flex-1 h-10 bg-red text-white rounded-btn text-[14px] font-medium font-sans hover:bg-opacity-90 transition-all disabled:opacity-50"
                  >
                    {deleting ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto block" />
                    ) : 'Delete'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-3">
                <button
                  onClick={() => setConfirmDelete(true)}
                  className="h-12 px-4 border-[1.5px] border-red text-red rounded-btn text-[14px] font-medium font-sans flex items-center gap-2 hover:bg-red/5 transition-colors"
                >
                  <Trash2 size={16} /> Delete
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex-1 h-12 bg-teal text-white rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-50"
                >
                  {saving ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : 'Save changes'}
                </button>
              </div>
            )}
          </div>
        ) : (
          <p className="text-[14px] text-muted font-sans">Expense not found.</p>
        )}
      </div>
    </div>
  );
}
