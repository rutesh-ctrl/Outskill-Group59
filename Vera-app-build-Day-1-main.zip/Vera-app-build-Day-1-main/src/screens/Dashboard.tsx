import { useEffect, useState, useCallback } from 'react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
} from 'recharts';
import { supabase } from '../lib/supabase';
import { callAI } from '../lib/ai';
import { useAuth } from '../context/AuthContext';
import { Expense, Income, Category, CATEGORY_COLORS, GOAL_LABELS } from '../lib/types';
import { formatAmount, formatDate, getWeekStart, getMonthStart, toISODateString } from '../lib/currency';
import ExpenseDetailModal from '../components/ExpenseDetailModal';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

type TimeWindow = 'week' | 'month';

function CategoryBadge({ category }: { category: Category }) {
  const color = CATEGORY_COLORS[category];
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium uppercase tracking-wide"
      style={{ backgroundColor: `${color}20`, color }}
    >
      {category}
    </span>
  );
}

function SkeletonCard() {
  return (
    <div className="bg-surface rounded-card shadow-card p-6 space-y-3">
      <div className="h-4 bg-border rounded animate-pulse w-1/4" />
      <div className="h-6 bg-border rounded animate-pulse w-3/4" />
      <div className="h-4 bg-border rounded animate-pulse w-full" />
      <div className="h-4 bg-border rounded animate-pulse w-5/6" />
    </div>
  );
}

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [timeWindow, setTimeWindow] = useState<TimeWindow>('week');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [incomes, setIncomes] = useState<Income[]>([]);
  const [loadingExpenses, setLoadingExpenses] = useState(true);
  const [mentorSummary, setMentorSummary] = useState('');
  const [loadingMentor, setLoadingMentor] = useState(true);
  const [selectedExpenseId, setSelectedExpenseId] = useState<string | null>(null);

  const fetchExpenses = useCallback(async () => {
    if (!user) return;
    setLoadingExpenses(true);
    const today = new Date();
    let startDate: string;
    if (timeWindow === 'week') {
      startDate = toISODateString(getWeekStart(today));
    } else {
      startDate = toISODateString(getMonthStart(today));
    }
    const [{ data: expData }, { data: incData }] = await Promise.all([
      supabase
        .from('expenses')
        .select('*')
        .eq('user_id', user.id)
        .gte('expense_date', startDate)
        .order('created_at', { ascending: false }),
      supabase
        .from('income')
        .select('*')
        .eq('user_id', user.id)
        .gte('income_date', startDate)
        .order('created_at', { ascending: false }),
    ]);
    setExpenses((expData as Expense[]) || []);
    setIncomes((incData as Income[]) || []);
    setLoadingExpenses(false);
  }, [user, timeWindow]);

  const fetchOrGenerateMentor = useCallback(async () => {
    if (!user || !profile) return;
    setLoadingMentor(true);

    const weekStart = toISODateString(getWeekStart());
    const today = toISODateString(new Date());

    const { data: cached } = await supabase
      .from('ai_summaries')
      .select('*')
      .eq('user_id', user.id)
      .eq('week_start', weekStart)
      .gte('generated_at', today)
      .maybeSingle();

    if (cached) {
      setMentorSummary(cached.summary_text);
      setLoadingMentor(false);
      return;
    }

    const weekStartDate = getWeekStart();
    const monthStart = toISODateString(getMonthStart(new Date()));

    const [{ data: weekExpenses }, { data: weekIncomes }, { data: monthIncomes }] = await Promise.all([
      supabase.from('expenses').select('*').eq('user_id', user.id).gte('expense_date', weekStart),
      supabase.from('income').select('*').eq('user_id', user.id).gte('income_date', weekStart),
      supabase.from('income').select('*').eq('user_id', user.id).gte('income_date', monthStart),
    ]);

    const expList = (weekExpenses as Expense[]) || [];
    const weekIncomeList = (weekIncomes as Income[]) || [];
    const monthIncomeList = (monthIncomes as Income[]) || [];

    const totalSpent = expList.reduce((s, e) => s + e.amount, 0);
    const weekLoggedIncome = weekIncomeList.reduce((s, i) => s + i.amount, 0);
    const monthLoggedIncome = monthIncomeList.reduce((s, i) => s + i.amount, 0);
    const totalMonthlyIncome = (profile.monthly_income || 0) + monthLoggedIncome;
    const monthOutgoings = profile.monthly_outgoings || 0;
    const remaining = totalMonthlyIncome - monthOutgoings - totalSpent;

    const byCategory: Record<string, number> = {};
    expList.forEach((e) => {
      byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
    });
    const essentialSpent = expList.filter((e) => e.is_essential).reduce((s, e) => s + e.amount, 0);
    const avoidableSpent = totalSpent - essentialSpent;

    const goalLabel = GOAL_LABELS[profile.goal as keyof typeof GOAL_LABELS] || profile.goal;

    const firstName = profile.display_name?.split(' ')[0] || 'there';
    const systemPrompt = `You are a financial mentor — warm, direct, empowering. Like Suze Orman. You know this person's goal. Use it. Never give generic advice.

Start your response with exactly "Hi ${firstName}," on its own line, then a blank line, then the main paragraph.

Write 3 to 4 sentences in the main paragraph:
1. Open with something specific and positive from their week's data — use exact amounts
2. Reference their GOAL directly — frame the insight around what it means for them
3. Name one area of concern — honest, never shaming
4. End with one concrete, actionable suggestion as their choice

Rules: No bullet points. Flowing sentences only. Use the currency symbol for all amounts. Never use the words: wasted, bad, wrong, irresponsible. Never mention any app name or brand name.`;

    const userMsg = JSON.stringify({
      goal: profile.goal,
      goal_label: goalLabel,
      currency_code: profile.currency_code,
      currency_symbol: profile.currency_symbol,
      week_start: toISODateString(weekStartDate),
      week_total_spent: totalSpent,
      week_logged_income: weekLoggedIncome,
      week_essential_spent: essentialSpent,
      week_avoidable_spent: avoidableSpent,
      week_by_category: byCategory,
      week_transaction_count: expList.length,
      monthly_base_income: profile.monthly_income,
      monthly_logged_income: monthLoggedIncome,
      monthly_total_income: totalMonthlyIncome,
      monthly_outgoings: monthOutgoings,
      monthly_remaining_balance: remaining,
    });

    try {
      const summary = await callAI(systemPrompt, userMsg, 200, 0.6);
      await supabase.from('ai_summaries').upsert(
        {
          user_id: user.id,
          summary_text: summary,
          week_start: weekStart,
          generated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
      setMentorSummary(summary);
    } catch {
      setMentorSummary('');
    } finally {
      setLoadingMentor(false);
    }
  }, [user, profile]);

  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  useEffect(() => {
    fetchOrGenerateMentor();
  }, [fetchOrGenerateMentor]);

  const totalSpent = expenses.reduce((s, e) => s + e.amount, 0);
  const totalIncome = incomes.reduce((s, i) => s + i.amount, 0);
  const currencyCode = profile?.currency_code || 'GBP';

  const categoryData = Object.entries(
    expenses.reduce((acc: Record<string, number>, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {})
  )
    .map(([name, value]) => ({ name: name as Category, value }))
    .sort((a, b) => b.value - a.value);

  type Transaction =
    | { kind: 'expense'; id: string; description: string; category: string; amount: number; currency_code: string; date: string; created_at: string }
    | { kind: 'income'; id: string; description: string; category: string; amount: number; currency_code: string; date: string; created_at: string };

  const transactions: Transaction[] = [
    ...expenses.map((e) => ({
      kind: 'expense' as const,
      id: e.id,
      description: e.description,
      category: e.category,
      amount: e.amount,
      currency_code: e.currency_code,
      date: e.expense_date,
      created_at: e.created_at,
    })),
    ...incomes.map((i) => ({
      kind: 'income' as const,
      id: i.id,
      description: i.description || i.category,
      category: i.category,
      amount: i.amount,
      currency_code: i.currency_code,
      date: i.income_date,
      created_at: i.created_at,
    })),
  ]
    .sort((a, b) => {
      const dateDiff = b.date.localeCompare(a.date);
      if (dateDiff !== 0) return dateDiff;
      return b.created_at.localeCompare(a.created_at);
    })
    .slice(0, 15);

  return (
    <div className="min-h-screen bg-page pb-28">
      {/* Nav */}
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Insights</h1>
        </div>
      </nav>

      <div className="max-w-lg mx-auto px-4 pt-6 space-y-4">
        {/* Hero */}
        <div className="bg-surface rounded-card shadow-card p-6">
          <p className="text-[13px] text-muted font-sans mb-1">Your {timeWindow === 'week' ? 'week' : 'month'} so far</p>
          {loadingExpenses ? (
            <>
              <div className="h-10 bg-border rounded animate-pulse w-2/3 mb-2" />
              <div className="h-4 bg-border rounded animate-pulse w-1/3" />
            </>
          ) : (
            <>
              <p
                className="font-sans font-semibold text-navy text-[36px] leading-none"
                style={{ fontVariantNumeric: 'tabular-nums' }}
              >
                {formatAmount(totalSpent, currencyCode)}
              </p>
              <div className="flex items-center gap-3 mt-1.5">
                <p className="text-[13px] text-muted font-sans">
                  {expenses.length} expense{expenses.length !== 1 ? 's' : ''}
                </p>
                {totalIncome > 0 && (
                  <p className="text-[13px] font-sans text-teal font-medium">
                    +{formatAmount(totalIncome, currencyCode)} additional income
                  </p>
                )}
              </div>
            </>
          )}

          {/* Toggle */}
          <div className="flex mt-5 border-b border-border">
            {(['week', 'month'] as TimeWindow[]).map((w) => (
              <button
                key={w}
                onClick={() => setTimeWindow(w)}
                className={`px-4 py-2 text-[14px] font-medium font-sans capitalize transition-all ${
                  timeWindow === w
                    ? 'text-teal border-b-2 border-teal -mb-px'
                    : 'text-muted hover:text-slate'
                }`}
              >
                {w}
              </button>
            ))}
          </div>
        </div>

        {/* AI Mentor Card */}
        {loadingMentor ? (
          <SkeletonCard />
        ) : mentorSummary ? (
          <div className="p-5 bg-ai-bg border-l-[3px] border-teal rounded-r-card shadow-card">
            <p className="font-heading italic text-[15px] text-slate leading-relaxed whitespace-pre-line">
              {mentorSummary}
            </p>
          </div>
        ) : null}

        {/* Category Chart */}
        {!loadingExpenses && categoryData.length >= 2 && (
          <div className="bg-surface rounded-card shadow-card p-6">
            <h3 className="font-heading font-semibold text-navy text-[16px] mb-4">Spending by category</h3>
            <div className="flex gap-4 items-center">
              <div className="w-36 h-36 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={36}
                      outerRadius={60}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={CATEGORY_COLORS[entry.name as Category]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value) => formatAmount(Number(value), currencyCode)}
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid #E4E8EF',
                        fontSize: '13px',
                        fontFamily: 'Inter, sans-serif',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2">
                {categoryData.map((c) => (
                  <div key={c.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: CATEGORY_COLORS[c.name as Category] }}
                      />
                      <span className="text-[13px] text-slate font-sans">{c.name}</span>
                    </div>
                    <span
                      className="text-[13px] font-medium text-slate font-sans"
                      style={{ fontVariantNumeric: 'tabular-nums' }}
                    >
                      {formatAmount(c.value, currencyCode)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Transactions List */}
        <div className="bg-surface rounded-card shadow-card p-6">
          <h3 className="font-heading font-semibold text-navy text-[16px] mb-4">Recent transactions</h3>
          {loadingExpenses ? (
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex justify-between items-start">
                  <div className="space-y-1.5 flex-1">
                    <div className="h-4 bg-border rounded animate-pulse w-2/3" />
                    <div className="h-3 bg-border rounded animate-pulse w-1/3" />
                  </div>
                  <div className="h-5 bg-border rounded animate-pulse w-16 ml-4" />
                </div>
              ))}
            </div>
          ) : transactions.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-[14px] text-muted font-sans">Nothing logged yet — tap + to add your first entry</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {transactions.map((t) => (
                <button
                  key={`${t.kind}-${t.id}`}
                  onClick={() => t.kind === 'expense' ? setSelectedExpenseId(t.id) : undefined}
                  className={`w-full flex items-center justify-between py-3 -mx-2 px-2 rounded-btn transition-colors ${
                    t.kind === 'expense' ? 'hover:bg-page/60 cursor-pointer' : 'cursor-default'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-[13px] font-bold ${
                      t.kind === 'income' ? 'bg-teal/10 text-teal' : 'bg-red/8 text-red'
                    }`}>
                      {t.kind === 'income' ? '+' : '−'}
                    </div>
                    <div className="flex flex-col items-start gap-0.5 min-w-0">
                      <span className="font-sans font-medium text-[14px] text-slate truncate max-w-[160px]">
                        {t.description}
                      </span>
                      <div className="flex items-center gap-2">
                        {t.kind === 'expense' ? (
                          <CategoryBadge category={t.category as Category} />
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium uppercase tracking-wide bg-teal/10 text-teal">
                            {t.category}
                          </span>
                        )}
                        <span className="text-[12px] text-muted font-sans">{formatDate(t.date)}</span>
                      </div>
                    </div>
                  </div>
                  <span
                    className={`font-sans font-semibold text-[15px] ml-3 shrink-0 ${
                      t.kind === 'income' ? 'text-teal' : 'text-navy'
                    }`}
                    style={{ fontVariantNumeric: 'tabular-nums' }}
                  >
                    {t.kind === 'income' ? '+' : ''}{formatAmount(t.amount, t.currency_code)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <BottomNav />

      {/* Expense Detail Modal */}
      {selectedExpenseId && (
        <ExpenseDetailModal
          expenseId={selectedExpenseId}
          currencyCode={currencyCode}
          onClose={() => setSelectedExpenseId(null)}
          onUpdate={fetchExpenses}
        />
      )}
    </div>
  );
}
