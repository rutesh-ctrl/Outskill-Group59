import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, RefreshCw, CheckCircle2, XCircle, Camera, Type, X } from 'lucide-react';
import { callAI } from '../lib/ai';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { formatAmount, toISODateString } from '../lib/currency';
import { Category, GOAL_LABELS, CATEGORY_COLORS, CATEGORIES } from '../lib/types';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

interface ParsedExpense {
  amount: number;
  currency_code: string;
  description: string;
  category: Category;
  is_essential: boolean;
  confidence: number;
  micro_reaction: string;
}

type Step = 'input' | 'confirm';
type InputMode = 'text' | 'receipt';

function CategoryBadge({ category }: { category: Category }) {
  const color = CATEGORY_COLORS[category];
  return (
    <span
      className="inline-flex items-center px-3 py-1 rounded-full text-[12px] font-semibold uppercase tracking-wide"
      style={{ backgroundColor: `${color}18`, color }}
    >
      {category}
    </span>
  );
}

function fileToBase64(file: File): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip the data:mime;base64, prefix
      const base64 = result.split(',')[1];
      resolve({ base64, mimeType: file.type || 'image/jpeg' });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function AddExpense() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<Step>('input');
  const [inputMode, setInputMode] = useState<InputMode>('text');
  const [input, setInput] = useState('');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [parsed, setParsed] = useState<ParsedExpense | null>(null);
  const [isEssential, setIsEssential] = useState<boolean | null>(null);
  const [saving, setSaving] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (step === 'input' && inputMode === 'text') textareaRef.current?.focus();
  }, [step, inputMode]);

  const buildSystemPrompt = () => {
    if (!profile) return '';
    const goalLabel = GOAL_LABELS[profile.goal as keyof typeof GOAL_LABELS] || profile.goal;
    const today = toISODateString(new Date());
    return `You are Vera's financial assistant. Parse the user's expense and return structured JSON.

User context:
- Goal: ${goalLabel}
- Monthly take-home: ${profile.currency_symbol}${profile.monthly_income}
- Monthly outgoings: ${profile.currency_symbol}${profile.monthly_outgoings}
- Default currency: ${profile.currency_code} (${profile.currency_symbol})
- Today: ${today}

Return ONLY valid JSON, no markdown, no code fences:
{
  "amount": number (required — the total amount paid),
  "currency_code": "ISO 4217 — use user default unless a different symbol appears",
  "description": "3 to 6 words, clean and concise",
  "category": "exactly one of: Food & Drink, Transport, Shopping, Entertainment, Health, Subscriptions, Bills, Other",
  "is_essential": true or false (your best guess — the user will confirm),
  "confidence": number between 0 and 1,
  "micro_reaction": "1 short sentence — specific insight about this spend relative to their goal. Honest, never shaming."
}`;
  };

  const handleTextSubmit = async () => {
    if (!input.trim() || !profile) return;
    setLoading(true);
    setError('');
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setLoading(false);
      setError('Taking too long — please try again');
    }, 12000);
    try {
      const raw = await callAI(buildSystemPrompt(), input, 300, 0.3);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      const result: ParsedExpense = JSON.parse(raw.replace(/```json|```/g, '').trim());
      setParsed(result);
      setIsEssential(result.is_essential);
      setStep('confirm');
    } catch {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      setError('Something went wrong — please try again');
    } finally {
      setLoading(false);
    }
  };

  const handleReceiptFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }
    setReceiptFile(file);
    setError('');
    const url = URL.createObjectURL(file);
    setReceiptPreview(url);
  };

  const handleReceiptSubmit = async () => {
    if (!receiptFile || !profile) return;
    setLoading(true);
    setError('');
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setLoading(false);
      setError('Taking too long — please try again');
    }, 20000);
    try {
      const { base64, mimeType } = await fileToBase64(receiptFile);
      const raw = await callAI(
        buildSystemPrompt(),
        'Please parse this receipt image and extract the expense details.',
        400,
        0.2,
        { base64, mimeType }
      );
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      const result: ParsedExpense = JSON.parse(raw.replace(/```json|```/g, '').trim());
      setParsed(result);
      setIsEssential(result.is_essential);
      setStep('confirm');
    } catch {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      setError('Could not read the receipt — try again or type it manually');
    } finally {
      setLoading(false);
    }
  };

  const handleClearReceipt = () => {
    setReceiptFile(null);
    if (receiptPreview) URL.revokeObjectURL(receiptPreview);
    setReceiptPreview(null);
    setError('');
  };

  const handleSave = async (essential: boolean) => {
    if (!parsed || !user || !profile) return;
    setIsEssential(essential);
    setSaving(true);
    try {
      const rawInput = inputMode === 'receipt' ? '[Receipt photo]' : input;
      const { error: insertError } = await supabase.from('expenses').insert({
        user_id: user.id,
        amount: parsed.amount,
        currency_code: parsed.currency_code || profile.currency_code,
        description: parsed.description,
        category: parsed.category,
        is_essential: essential,
        is_seed: false,
        raw_input: rawInput,
        ai_confidence: parsed.confidence,
        micro_reaction: parsed.micro_reaction,
        expense_date: toISODateString(new Date()),
      });
      if (insertError) throw insertError;
      navigate('/');
    } catch {
      setError('Could not save — please try again');
      setSaving(false);
    }
  };

  const handleBack = () => {
    if (step === 'confirm') {
      setStep('input');
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-page flex flex-col">
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <button onClick={handleBack} className="p-2 rounded-btn hover:bg-border/50 transition-colors text-navy mr-1">
            <ArrowLeft size={20} />
          </button>
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">
            {step === 'input' ? 'Add Expense' : 'Confirm Expense'}
          </h1>
        </div>
      </nav>

      <div className="flex-1 max-w-lg mx-auto w-full px-4 py-8">

        {/* ── STEP 1: Input ── */}
        {step === 'input' && (
          <div className="space-y-5">
            <div>
              <p className="font-heading font-semibold text-navy text-[22px] mb-1">
                What did you spend on?
              </p>
              <p className="text-[13px] text-muted font-sans">
                Type it out or photograph your receipt
              </p>
            </div>

            {/* Mode toggle — segmented control */}
            <div className="flex bg-border/40 rounded-[12px] p-1 gap-1">
              <button
                onClick={() => { setInputMode('text'); setError(''); }}
                className={`flex-1 flex items-center justify-center gap-2 h-9 rounded-[10px] text-[13px] font-semibold font-sans transition-all ${
                  inputMode === 'text' ? 'bg-teal text-white shadow-sm' : 'text-muted hover:text-slate'
                }`}
              >
                <Type size={14} /> Type it
              </button>
              <button
                onClick={() => { setInputMode('receipt'); setError(''); }}
                className={`flex-1 flex items-center justify-center gap-2 h-9 rounded-[10px] text-[13px] font-semibold font-sans transition-all ${
                  inputMode === 'receipt' ? 'bg-teal text-white shadow-sm' : 'text-muted hover:text-slate'
                }`}
              >
                <Camera size={14} /> Scan receipt
              </button>
            </div>

            {/* Text input */}
            {inputMode === 'text' && (
              <div className="bg-surface rounded-card shadow-card p-5">
                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => { setInput(e.target.value); setError(''); }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleTextSubmit(); }
                  }}
                  placeholder="e.g. coffee £4.50, Uber home, Netflix £10.99..."
                  rows={4}
                  className="w-full px-0 py-0 border-none outline-none text-[16px] font-sans text-slate bg-transparent resize-none placeholder:text-muted/60 leading-relaxed"
                />
              </div>
            )}

            {/* Receipt input */}
            {inputMode === 'receipt' && (
              <div>
                {receiptPreview ? (
                  <div className="relative rounded-card overflow-hidden bg-surface shadow-card">
                    <img
                      src={receiptPreview}
                      alt="Receipt"
                      className="w-full max-h-72 object-contain bg-page"
                    />
                    <button
                      onClick={handleClearReceipt}
                      className="absolute top-3 right-3 w-8 h-8 bg-navy/70 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-navy transition-colors"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border-2 border-dashed border-border rounded-card bg-surface hover:border-teal/50 hover:bg-teal/3 transition-all p-10 flex flex-col items-center gap-3 text-center"
                  >
                    <div className="w-14 h-14 rounded-full bg-teal/10 flex items-center justify-center">
                      <Camera size={26} className="text-teal" />
                    </div>
                    <div>
                      <p className="font-sans font-semibold text-navy text-[15px]">Take or upload a photo</p>
                      <p className="font-sans text-[13px] text-muted mt-1">Vera will read the receipt and fill in the details</p>
                    </div>
                    <span className="mt-1 px-4 py-2 bg-teal text-white rounded-btn text-[13px] font-semibold font-sans">
                      Choose photo
                    </span>
                  </button>
                )}

                {/* Hidden file input — accept images, allow camera on mobile */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleReceiptFile(file);
                    e.target.value = '';
                  }}
                />
              </div>
            )}

            {error && (
              <div className="p-4 bg-red/10 border border-red/20 rounded-btn flex items-center gap-2">
                <RefreshCw size={15} className="text-red shrink-0" />
                <p className="text-[13px] text-red font-sans">{error}</p>
              </div>
            )}

            <button
              onClick={inputMode === 'text' ? handleTextSubmit : handleReceiptSubmit}
              disabled={inputMode === 'text' ? (!input.trim() || loading) : (!receiptFile || loading)}
              className="w-full h-[52px] bg-teal text-white rounded-[12px] text-[15px] font-medium font-sans flex items-center justify-center gap-2.5 hover:bg-opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  {inputMode === 'receipt' ? 'Reading receipt...' : 'Analysing...'}
                </>
              ) : (
                <>
                  {inputMode === 'receipt' ? <Camera size={16} /> : <Send size={16} />}
                  {inputMode === 'receipt' ? 'Process receipt' : 'Submit'}
                </>
              )}
            </button>
          </div>
        )}

        {/* ── STEP 2: Confirm ── */}
        {step === 'confirm' && parsed && (
          <div className="space-y-5">

            {/* Show receipt thumbnail if it came from photo */}
            {inputMode === 'receipt' && receiptPreview && (
              <div className="rounded-card overflow-hidden shadow-card">
                <img src={receiptPreview} alt="Receipt" className="w-full max-h-40 object-contain bg-page" />
              </div>
            )}

            <div className="bg-surface rounded-card shadow-card p-6">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="min-w-0">
                  <p className="font-sans font-bold text-navy text-[36px] leading-none tracking-tight"
                    style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatAmount(parsed.amount, parsed.currency_code || profile!.currency_code)}
                  </p>
                  <p className="font-sans text-slate text-[16px] mt-2 font-medium">{parsed.description}</p>
                </div>
                <CategoryBadge category={parsed.category} />
              </div>

              <div className="pt-4 border-t border-border">
                <p className="text-[11px] uppercase tracking-widest text-muted font-sans mb-2.5">Category</p>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map((cat) => {
                    const active = parsed.category === cat;
                    const color = CATEGORY_COLORS[cat];
                    return (
                      <button key={cat} onClick={() => setParsed({ ...parsed, category: cat })}
                        className="px-2.5 py-1 rounded-full text-[12px] font-medium transition-all"
                        style={active ? { backgroundColor: color, color: '#fff' } : { backgroundColor: `${color}12`, color }}>
                        {cat}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {parsed.micro_reaction && (
              <div className="p-5 bg-ai-bg border-l-[3px] border-teal rounded-r-card">
                <p className="text-[11px] uppercase tracking-widest text-muted font-sans mb-2">Vera says</p>
                <p className="font-heading italic text-[15px] text-slate leading-relaxed">
                  {parsed.micro_reaction}
                </p>
              </div>
            )}

            <div>
              <p className="text-[13px] font-semibold text-slate font-sans mb-3">
                Is this spend essential or avoidable?
              </p>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => handleSave(true)} disabled={saving}
                  className={`relative h-24 rounded-card border-2 flex flex-col items-center justify-center gap-2 transition-all ${
                    isEssential === true ? 'border-teal bg-teal/8 shadow-sm' : 'border-border bg-surface hover:border-teal/50 hover:bg-teal/4'
                  } disabled:opacity-50`}>
                  {saving && isEssential === true
                    ? <span className="w-5 h-5 border-2 border-teal border-t-transparent rounded-full animate-spin" />
                    : <CheckCircle2 size={24} className="text-teal" />}
                  <span className="font-sans font-semibold text-[14px] text-navy">Essential</span>
                  <span className="font-sans text-[11px] text-muted">Had to spend this</span>
                </button>

                <button onClick={() => handleSave(false)} disabled={saving}
                  className={`relative h-24 rounded-card border-2 flex flex-col items-center justify-center gap-2 transition-all ${
                    isEssential === false ? 'border-red bg-red/8 shadow-sm' : 'border-border bg-surface hover:border-red/40 hover:bg-red/4'
                  } disabled:opacity-50`}>
                  {saving && isEssential === false
                    ? <span className="w-5 h-5 border-2 border-red border-t-transparent rounded-full animate-spin" />
                    : <XCircle size={24} className="text-red" />}
                  <span className="font-sans font-semibold text-[14px] text-navy">Avoidable</span>
                  <span className="font-sans text-[11px] text-muted">Could have skipped it</span>
                </button>
              </div>

              <p className="text-[11px] text-muted font-sans text-center mt-2.5">
                Vera suggests:{' '}
                <span className={`font-semibold ${parsed.is_essential ? 'text-teal' : 'text-red'}`}>
                  {parsed.is_essential ? 'Essential' : 'Avoidable'}
                </span>
                {' '}— tap to confirm or override
              </p>
            </div>

            {error && (
              <div className="p-4 bg-red/10 border border-red/20 rounded-btn">
                <p className="text-[13px] text-red font-sans">{error}</p>
              </div>
            )}
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
