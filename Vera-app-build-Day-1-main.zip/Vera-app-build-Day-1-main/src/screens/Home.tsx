import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus, Target, TrendingDown, Wallet, Pencil, Check, X,
  ChevronRight, Lightbulb, Flag, Trash2, AlertTriangle,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import {
  Expense, Income, Category, CATEGORY_COLORS, GOAL_LABELS,
  GOAL_TARGET_LABEL, GOAL_TARGET_PLACEHOLDER, UserGoal, CURRENCY_MULTIPLIERS,
} from '../lib/types';
import { formatAmount, toISODateString, getMonthStart } from '../lib/currency';
import ExpenseDetailModal from '../components/ExpenseDetailModal';
import BottomNav from '../components/BottomNav';
import CelebrationOverlay from '../components/CelebrationOverlay';
import VeraLogo from '../components/VeraLogo';

// ─── Daily tips ────────────────────────────────────────────────────────────────

interface TipTemplate {
  action: string;
  saving: (sym: string, mult: number) => string;
}

const DAILY_TIP_TEMPLATES: TipTemplate[] = [
  { action: 'Pack a lunch today instead of buying out', saving: (s, m) => `save ~${s}${Math.round(8 * m)}–${Math.round(12 * m)} vs eating out` },
  { action: 'Make coffee at home before you leave', saving: (s, m) => `save ${s}${Math.round(3 * m)}–${Math.round(5 * m)} on your commute` },
  { action: 'Unsubscribe from one unused streaming service', saving: (s, m) => `save ${s}${Math.round(8 * m)}–${Math.round(16 * m)}/month going forward` },
  { action: 'Plan dinners for the next 3 days before grocery shopping', saving: () => 'cut food waste by up to 30%' },
  { action: 'Walk or cycle one journey you would normally pay for', saving: (s, m) => `save ${s}${Math.round(4 * m)}–${Math.round(15 * m)} on transport` },
  { action: 'Check your bank for any forgotten direct debits', saving: (s, m) => `could free up ${s}${Math.round(10 * m)}–${Math.round(50 * m)}/month` },
  { action: 'Batch-cook tonight — make portions for 2–3 days', saving: (s, m) => `save ${s}${Math.round(20 * m)}–${Math.round(30 * m)} across the week` },
  { action: 'Use a supermarket own-brand on one item today', saving: () => 'typically 30–40% cheaper' },
  { action: 'Skip one impulse buy and log it as a win instead', saving: (s, m) => `avg impulse purchase is ${s}${Math.round(12 * m)}–${Math.round(25 * m)}` },
  { action: 'Refill a water bottle rather than buying one', saving: (s, m) => `save ${s}${(1.5 * m).toFixed(2).replace(/\.?0+$/, '')}–${Math.round(3 * m)} per day` },
  { action: 'Move your daily budget savings into a pot right now', saving: () => 'small transfers compound fast' },
  { action: "Cook once, eat twice — repurpose tonight's dinner for lunch", saving: (s, m) => `save ${s}${Math.round(6 * m)}–${Math.round(10 * m)} tomorrow` },
  { action: 'Use cashback on your next online purchase', saving: () => 'typically 1–5% back on spend' },
  { action: 'Delay one non-essential purchase by 48 hours', saving: () => "you'll skip ~70% of impulse buys" },
  { action: 'Check if you qualify for any bills discounts or loyalty rates', saving: (s, m) => `could save ${s}${Math.round(50 * m)}–${Math.round(200 * m)}/year` },
  { action: 'Walk to your first errand today instead of driving', saving: () => 'save on fuel and parking' },
  { action: 'Set a 15-minute no-spend challenge on your lunch break', saving: () => 'keeps daily spend visible' },
  { action: 'Review your subscriptions — pick one to cancel or pause', saving: (s, m) => `avg household wastes ${s}${Math.round(45 * m)}/month` },
  { action: 'Bring snacks from home for the afternoon', saving: (s, m) => `save ${s}${Math.round(2 * m)}–${Math.round(5 * m)} on vending or cafe trips` },
  { action: 'Track every spend today, even small ones', saving: () => 'awareness alone cuts spending by ~15%' },
  { action: 'Use loyalty points or vouchers before they expire', saving: () => 'money already earned — use it' },
  { action: 'Order tap water instead of a soft drink when eating out', saving: (s, m) => `save ${s}${Math.round(2 * m)}–${Math.round(4 * m)} per meal` },
  { action: 'Buy a longer-lasting item once rather than a cheaper one twice', saving: () => 'saves money over 12 months' },
  { action: 'Check if any bills are up for renewal — renegotiate now', saving: () => 'loyal customers pay up to 30% more' },
  { action: "Swap one dinner out for a home cook version of your favourite dish", saving: (s, m) => `save ${s}${Math.round(15 * m)}–${Math.round(40 * m)} per meal` },
  { action: 'Use a library instead of buying a book or audiobook today', saving: () => 'free, and your taxes pay for it' },
  { action: 'Bring your own bag to avoid carrier bag charges', saving: () => 'small but consistent' },
  { action: 'Delete a shopping app from your phone for the day', saving: () => 'removes the fastest path to impulse spend' },
  { action: 'Review your Avoidable spend this month — pick one pattern to break', saving: () => 'awareness is the first step to change' },
  { action: 'Move a little extra into savings today', saving: (s, m) => `${s}${Math.round(5 * m)}/day = ${s}${Math.round(1825 * m).toLocaleString()}/year` },
  { action: 'Cook a simple meal from store-cupboard ingredients', saving: () => 'zero spend, full meal' },
];

function getTodayTip(symbol: string, currencyCode: string) {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const template = DAILY_TIP_TEMPLATES[dayOfYear % DAILY_TIP_TEMPLATES.length];
  const mult = CURRENCY_MULTIPLIERS[currencyCode] ?? 1;
  return { action: template.action, saving: template.saving(symbol, mult) };
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

function formatDayMonth() {
  return new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ─── Budget ring ───────────────────────────────────────────────────────────────
function BudgetRing({ spent, budget, currencyCode, symbol }: { spent: number; budget: number; currencyCode: string; symbol: string }) {
  const pct = Math.min(spent / budget, 1);
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - pct);
  let ringColor = '#0D9B8A';
  if (pct >= 0.75) ringColor = '#F5A623';
  if (pct >= 1) ringColor = '#E8495A';
  const remaining = budget - spent;
  const overBudget = remaining < 0;

  return (
    <div className="flex items-center gap-6">
      <div className="relative w-32 h-32 shrink-0">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r={radius} fill="none" stroke="#E4E8EF" strokeWidth="10" />
          <circle cx="60" cy="60" r={radius} fill="none" stroke={ringColor} strokeWidth="10"
            strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={strokeDashoffset}
            style={{ transition: 'stroke-dashoffset 0.6s ease, stroke 0.3s ease' }} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-sans font-bold text-navy text-[15px] leading-tight" style={{ fontVariantNumeric: 'tabular-nums' }}>
            {symbol}{Math.round(spent)}
          </span>
          <span className="font-sans text-muted text-[11px]">of {symbol}{Math.round(budget)}</span>
        </div>
      </div>
      <div className="flex-1 space-y-2">
        <div>
          <p className="text-[12px] text-muted font-sans uppercase tracking-wide mb-0.5">Today's spend</p>
          <p
            className={`font-sans font-semibold text-[18px] transition-colors ${overBudget ? 'text-red' : 'text-navy'}`}
            style={{ fontVariantNumeric: 'tabular-nums' }}
          >
            {formatAmount(spent, currencyCode)}
          </p>
        </div>
        <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-semibold transition-colors ${
          overBudget ? 'bg-red/10 text-red' : pct >= 0.75 ? 'bg-amber/15 text-amber' : 'bg-teal/10 text-teal'
        }`}>
          {overBudget
            ? <><AlertTriangle size={11} />{formatAmount(Math.abs(remaining), currencyCode)} over</>
            : `${formatAmount(remaining, currencyCode)} left`
          }
        </div>
        <div className="w-full bg-border rounded-full h-1.5 overflow-hidden">
          <div className="h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(pct * 100, 100)}%`, backgroundColor: ringColor }} />
        </div>
        {overBudget && (
          <p className="font-sans text-[11px] text-red leading-snug font-medium animate-slide-up">
            Be mindful — you're spending more than your budget.
          </p>
        )}
      </div>
    </div>
  );
}

// ─── Avoidable spend drawer ────────────────────────────────────────────────────
const AVOIDABLE_SUGGESTIONS: Record<string, string> = {
  'Food & Drink': 'Pack lunch 3 days a week and batch-cook on weekends — could save you significantly each month.',
  Transport: 'Consider walking, cycling, or public transport for shorter journeys where possible.',
  Shopping: 'Try a 48-hour rule before non-essential purchases — you\'ll skip most impulse buys.',
  Entertainment: 'Look for free or lower-cost alternatives: parks, free events, streaming sharing.',
  Health: 'Check if any of these could be covered by workplace benefits or NHS services.',
  Subscriptions: 'Audit your subscriptions — cancel anything you haven\'t used in the last 30 days.',
  Bills: 'Shop around at renewal time — loyalty often costs you 10–30% more than new customer rates.',
  Other: 'Review these individually — even cutting half could meaningfully improve your monthly balance.',
};

function AvoidableDrawer({ expenses, currencyCode, onClose, onSelectExpense }: {
  expenses: Expense[];
  currencyCode: string;
  onClose: () => void;
  onSelectExpense: (id: string) => void;
}) {
  const total = expenses.reduce((s, e) => s + e.amount, 0);
  const byCategory = expenses.reduce((acc: Record<string, { total: number; items: Expense[] }>, e) => {
    if (!acc[e.category]) acc[e.category] = { total: 0, items: [] };
    acc[e.category].total += e.amount;
    acc[e.category].items.push(e);
    return acc;
  }, {});
  const sorted = Object.entries(byCategory).sort((a, b) => b[1].total - a[1].total);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative w-full max-w-lg bg-surface rounded-t-[24px] shadow-2xl max-h-[85vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-border" />
        </div>
        <div className="px-5 pt-2 pb-4 border-b border-border flex items-start justify-between">
          <div>
            <h2 className="font-heading font-semibold text-navy text-[18px]">Avoidable spend</h2>
            <p className="text-[13px] text-muted font-sans mt-0.5">
              This month: <span className="font-semibold text-red">{formatAmount(total, currencyCode)}</span>
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-btn text-muted hover:text-slate transition-colors">
            <X size={20} />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-5">
          {sorted.map(([cat, { total: catTotal, items }]) => {
            const color = CATEGORY_COLORS[cat as Category] || '#6B7A8D';
            return (
              <div key={cat}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                    <span className="font-sans font-semibold text-[14px] text-slate">{cat}</span>
                  </div>
                  <span className="font-sans font-semibold text-[14px] text-navy" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatAmount(catTotal, currencyCode)}
                  </span>
                </div>
                <div className="bg-page rounded-[10px] divide-y divide-border mb-3">
                  {items.map((e) => (
                    <button key={e.id}
                      onClick={() => { onClose(); onSelectExpense(e.id); }}
                      className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-border/30 transition-colors first:rounded-t-[10px] last:rounded-b-[10px]">
                      <span className="font-sans text-[13px] text-slate text-left truncate max-w-[200px]">{e.description}</span>
                      <span className="font-sans text-[13px] font-medium text-slate ml-2 shrink-0" style={{ fontVariantNumeric: 'tabular-nums' }}>
                        {formatAmount(e.amount, e.currency_code)}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="flex gap-2.5 bg-ai-bg rounded-[10px] px-3 py-2.5">
                  <Lightbulb size={14} className="text-teal shrink-0 mt-0.5" />
                  <p className="font-sans text-[12px] text-slate leading-relaxed">
                    <span className="font-semibold text-teal">Vera: </span>
                    {AVOIDABLE_SUGGESTIONS[cat] || AVOIDABLE_SUGGESTIONS.Other}
                  </p>
                </div>
              </div>
            );
          })}
          {expenses.length === 0 && (
            <div className="py-8 text-center">
              <p className="text-[14px] text-muted font-sans">No avoidable spend logged this month — great work!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Goal card ─────────────────────────────────────────────────────────────────
type GoalType = 'save_more' | 'spend_less' | 'clear_debt';

interface GoalCardProps {
  goal: UserGoal;
  currencyCode: string;
  symbol: string;
  // For save_more: disposable saved this month
  // For spend_less: amount spent this month (compare against target)
  // For clear_debt: total debt paid (current_amount stored on goal)
  monthSpent: number;
  disposableSaved: number;
}

function GoalCard({ goal, currencyCode, monthSpent, disposableSaved, onDelete, onEdit }: GoalCardProps & { onDelete: (id: string) => void; onEdit: (goal: UserGoal) => void }) {
  let progress = 0;
  let progressLabel = '';
  let targetLabel = '';
  let pct: number | null = null;
  let ringColor = '#0D9B8A';
  let subNote = '';

  if (goal.goal_type === 'save_more') {
    // Progress = disposable balance this month (income - outgoings - spent)
    progress = Math.max(0, disposableSaved);
    progressLabel = formatAmount(progress, currencyCode);
    targetLabel = goal.target_amount ? formatAmount(goal.target_amount, currencyCode) : '';
    pct = goal.target_amount && goal.target_amount > 0
      ? Math.min((progress / goal.target_amount) * 100, 100) : null;
    subNote = 'Monthly disposable saved toward target';
  } else if (goal.goal_type === 'spend_less') {
    // Progress = how much UNDER target they are (lower spend = more progress)
    const target = goal.target_amount;
    if (target && target > 0) {
      progress = monthSpent;
      pct = Math.min((monthSpent / target) * 100, 150); // can exceed
      progressLabel = formatAmount(monthSpent, currencyCode);
      targetLabel = formatAmount(target, currencyCode);
      // Invert: green when spent < target
      if (monthSpent <= target) {
        ringColor = '#0D9B8A';
      } else if (monthSpent <= target * 1.1) {
        ringColor = '#F5A623';
      } else {
        ringColor = '#E8495A';
      }
      subNote = monthSpent <= target
        ? `${formatAmount(target - monthSpent, currencyCode)} under budget`
        : `${formatAmount(monthSpent - target, currencyCode)} over budget`;
    }
  } else if (goal.goal_type === 'clear_debt') {
    // current_amount = total debt paid so far (manually tracked)
    progress = goal.current_amount || 0;
    progressLabel = formatAmount(progress, currencyCode);
    targetLabel = goal.target_amount ? formatAmount(goal.target_amount, currencyCode) : '';
    pct = goal.target_amount && goal.target_amount > 0
      ? Math.min((progress / goal.target_amount) * 100, 100) : null;
    subNote = goal.target_amount
      ? `${formatAmount(Math.max(0, (goal.target_amount || 0) - progress), currencyCode)} remaining to clear`
      : 'Update paid amount using the edit button';
  }

  if (pct !== null) {
    if (goal.goal_type !== 'spend_less') {
      if (pct >= 100) ringColor = '#22C997';
      else if (pct >= 75) ringColor = '#F5A623';
    }
  }

  return (
    <div className="bg-page rounded-[12px] border border-border p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded-[6px] bg-teal/10 flex items-center justify-center shrink-0">
            <Flag size={12} className="text-teal" />
          </div>
          <div className="min-w-0">
            <p className="font-sans font-semibold text-navy text-[14px] leading-tight truncate">{goal.label}</p>
            {goal.target_amount && (
              <p className="font-sans text-[11px] text-muted">Target: {targetLabel}</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0 ml-2">
          <button onClick={() => onEdit(goal)} className="p-1.5 rounded-btn text-muted hover:text-slate transition-colors">
            <Pencil size={13} />
          </button>
          <button onClick={() => onDelete(goal.id)} className="p-1.5 rounded-btn text-muted hover:text-red transition-colors">
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {pct !== null ? (
        <div>
          <div className="flex justify-between text-[12px] font-sans mb-1.5">
            <span className="text-muted">
              {goal.goal_type === 'spend_less' ? 'Spent this month' : 'Progress'}
            </span>
            <span className="font-semibold" style={{ color: ringColor }}>
              {progressLabel}
              {goal.target_amount && <span className="text-muted font-normal"> / {targetLabel}</span>}
            </span>
          </div>
          <div className="w-full bg-border rounded-full h-2 overflow-hidden">
            <div className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${goal.goal_type === 'spend_less' ? Math.min(pct, 100) : pct}%`,
                backgroundColor: ringColor,
              }} />
          </div>
          <div className="flex items-center justify-between mt-1">
            <p className="text-[11px] font-sans" style={{ color: ringColor }}>{subNote}</p>
            {goal.goal_type !== 'spend_less' && (
              <p className="text-[11px]" style={{ color: ringColor }}>{Math.round(pct)}%</p>
            )}
          </div>
        </div>
      ) : (
        <div>
          <p className="text-[12px] text-muted font-sans">{subNote || 'No target set — tap edit to add one'}</p>
        </div>
      )}
    </div>
  );
}

// ─── Add/Edit goal modal ───────────────────────────────────────────────────────
const ALL_GOALS: GoalType[] = ['save_more', 'spend_less', 'clear_debt'];

interface GoalModalProps {
  editingGoal: UserGoal | null;
  userId: string;
  currencyCode: string;
  symbol: string;
  onClose: () => void;
  onSaved: () => void;
}

function GoalModal({ editingGoal, userId, symbol, onClose, onSaved }: GoalModalProps) {
  const [selectedType, setSelectedType] = useState<GoalType>(
    (editingGoal?.goal_type as GoalType) || 'save_more'
  );
  const [targetInput, setTargetInput] = useState(
    editingGoal?.target_amount ? String(editingGoal.target_amount) : ''
  );
  const [currentInput, setCurrentInput] = useState(
    editingGoal?.current_amount ? String(editingGoal.current_amount) : ''
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const targetLabel = GOAL_TARGET_LABEL[selectedType];
  const targetPlaceholder = GOAL_TARGET_PLACEHOLDER[selectedType];

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      const amount = targetInput ? parseFloat(targetInput) : null;
      const current = currentInput ? parseFloat(currentInput) : 0;
      const payload = {
        user_id: userId,
        goal_type: selectedType,
        label: GOAL_LABELS[selectedType],
        target_amount: amount && !isNaN(amount) ? amount : null,
        current_amount: !isNaN(current) ? current : 0,
        is_active: true,
      };
      if (editingGoal) {
        const { error: err } = await supabase.from('user_goals').update(payload).eq('id', editingGoal.id);
        if (err) throw err;
      } else {
        const { error: err } = await supabase.from('user_goals').insert(payload);
        if (err) throw err;
      }
      onSaved();
    } catch {
      setError('Could not save — please try again');
    } finally {
      setSaving(false);
    }
  };

  const goalSubtexts: Record<GoalType, string> = {
    save_more: 'Progress tracks your monthly disposable balance (income − outgoings − spending)',
    spend_less: 'Progress tracks your monthly spending against your target',
    clear_debt: 'Set the total debt and log how much you have paid off so far',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative w-full max-w-lg bg-surface rounded-t-[24px] shadow-2xl max-h-[90vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-border" />
        </div>
        <div className="px-5 pt-2 pb-4 border-b border-border flex items-center justify-between">
          <h2 className="font-heading font-semibold text-navy text-[18px]">
            {editingGoal ? 'Edit goal' : 'Add a goal'}
          </h2>
          <button onClick={onClose} className="p-2 rounded-btn text-muted hover:text-slate transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-4">
          <div className="space-y-2">
            {ALL_GOALS.map((g) => (
              <button key={g} onClick={() => setSelectedType(g)}
                className={`w-full text-left px-4 py-3 rounded-btn border transition-all ${
                  selectedType === g ? 'border-teal bg-ai-bg border-l-[3px]' : 'border-border bg-white hover:border-steel/30'
                }`}>
                <p className={`font-sans font-medium text-[14px] ${selectedType === g ? 'text-navy' : 'text-slate'}`}>
                  {GOAL_LABELS[g]}
                </p>
                {selectedType === g && (
                  <p className="font-sans text-[12px] text-muted mt-0.5">{goalSubtexts[g]}</p>
                )}
              </button>
            ))}
          </div>

          {targetLabel && (
            <div className="pt-2">
              <label className="block text-[13px] font-semibold text-slate font-sans mb-2">{targetLabel}</label>
              <div className="flex items-center gap-2">
                <span className="text-[16px] font-sans text-slate">{symbol}</span>
                <input
                  type="number"
                  value={targetInput}
                  onChange={(e) => setTargetInput(e.target.value)}
                  placeholder={targetPlaceholder}
                  min="0"
                  step="any"
                  className="flex-1 h-11 px-3 border border-border rounded-input text-[15px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
                />
              </div>
            </div>
          )}

          {selectedType === 'clear_debt' && (
            <div className="pt-1">
              <label className="block text-[13px] font-semibold text-slate font-sans mb-2">Amount already paid off</label>
              <div className="flex items-center gap-2">
                <span className="text-[16px] font-sans text-slate">{symbol}</span>
                <input
                  type="number"
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  placeholder="e.g. 500"
                  min="0"
                  step="any"
                  className="flex-1 h-11 px-3 border border-border rounded-input text-[15px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
                />
              </div>
              <p className="text-[12px] text-muted font-sans mt-1.5">Update this each time you make a repayment</p>
            </div>
          )}

          {error && <p className="text-[13px] text-red font-sans">{error}</p>}
        </div>

        <div className="px-5 pb-6 pt-3 border-t border-border">
          <button onClick={handleSave} disabled={saving}
            className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-semibold font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-40">
            {saving
              ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : <><Check size={16} /> {editingGoal ? 'Save changes' : 'Add goal'}</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────────
export default function Home() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();

  const [todayExpenses, setTodayExpenses] = useState<Expense[]>([]);
  const [monthExpenses, setMonthExpenses] = useState<Expense[]>([]);
  const [monthIncomes, setMonthIncomes] = useState<Income[]>([]);
  const [loadingExpenses, setLoadingExpenses] = useState(true);
  const [selectedExpenseId, setSelectedExpenseId] = useState<string | null>(null);
  const [showAvoidable, setShowAvoidable] = useState(false);

  const [goals, setGoals] = useState<UserGoal[]>([]);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [editingGoal, setEditingGoal] = useState<UserGoal | null>(null);

  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput] = useState('');
  const [savingBudget, setSavingBudget] = useState(false);

  const [celebratingGoal, setCelebratingGoal] = useState<UserGoal | null>(null);
  const [activeDrawer, setActiveDrawer] = useState<'income' | 'spent' | 'remaining' | null>(null);

  const fetchExpenses = useCallback(async () => {
    if (!user) return;
    setLoadingExpenses(true);
    const todayStr = toISODateString(new Date());
    const monthStr = toISODateString(getMonthStart(new Date()));
    const [{ data: expData }, { data: incData }] = await Promise.all([
      supabase
        .from('expenses').select('*').eq('user_id', user.id)
        .gte('expense_date', monthStr)
        .order('expense_date', { ascending: false })
        .order('created_at', { ascending: false }),
      supabase
        .from('income').select('*').eq('user_id', user.id)
        .gte('income_date', monthStr)
        .order('income_date', { ascending: false }),
    ]);
    const all = (expData as Expense[]) || [];
    setMonthExpenses(all);
    setMonthIncomes((incData as Income[]) || []);
    setTodayExpenses(all.filter((e) => e.expense_date === todayStr));
    setLoadingExpenses(false);
  }, [user]);

  const fetchGoals = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('user_goals').select('*').eq('user_id', user.id)
      .eq('is_active', true).order('created_at', { ascending: true });
    setGoals((data as UserGoal[]) || []);
  }, [user]);

  useEffect(() => { fetchExpenses(); }, [fetchExpenses]);
  useEffect(() => { fetchGoals(); }, [fetchGoals]);

  // Check for newly-completed goals and fire the celebration (once per goal, tracked in localStorage)
  useEffect(() => {
    if (!goals.length || loadingExpenses) return;
    const profileInc = profile?.monthly_income || 0;
    const loggedInc = monthIncomes.reduce((s, i) => s + i.amount, 0);
    const effectiveIncome = profileInc + loggedInc;
    const monthOutgo = profile?.monthly_outgoings || 0;
    const monthSpentNow = monthExpenses.reduce((s, e) => s + e.amount, 0);
    const disposable = Math.max(0, (effectiveIncome - monthOutgo) - monthSpentNow);

    const monthSpentNow2 = monthExpenses.reduce((s, e) => s + e.amount, 0);
    for (const goal of goals) {
      if (!goal.target_amount || goal.target_amount <= 0) continue;
      let progress: number;
      if (goal.goal_type === 'spend_less') {
        // Celebrate when spent is at or under target
        progress = goal.target_amount - monthSpentNow2;
      } else if (goal.goal_type === 'clear_debt') {
        progress = goal.current_amount || 0;
      } else {
        progress = disposable;
      }
      const pct = goal.goal_type === 'spend_less'
        ? (progress >= 0 ? 100 : 0)
        : (progress / goal.target_amount) * 100;
      if (pct < 100) continue;
      const key = `celebrated_goal_${goal.id}`;
      if (localStorage.getItem(key)) continue;
      localStorage.setItem(key, '1');
      setCelebratingGoal(goal);
      break; // show one at a time
    }
  }, [goals, monthExpenses, monthIncomes, loadingExpenses, profile]);

  const handleDeleteGoal = async (id: string) => {
    await supabase.from('user_goals').update({ is_active: false }).eq('id', id);
    fetchGoals();
  };

  const handleSaveBudget = async () => {
    if (!user) return;
    const val = parseFloat(budgetInput);
    if (isNaN(val) || val <= 0) return;
    setSavingBudget(true);
    await supabase.from('user_profiles').update({ daily_budget: val }).eq('user_id', user.id);
    await refreshProfile();
    setSavingBudget(false);
    setEditingBudget(false);
  };

  const handleClearBudget = async () => {
    if (!user) return;
    await supabase.from('user_profiles').update({ daily_budget: null }).eq('user_id', user.id);
    await refreshProfile();
    setEditingBudget(false);
  };

  const currencyCode = profile?.currency_code || 'GBP';
  const symbol = profile?.currency_symbol || '£';
  const firstName = profile?.display_name?.split(' ')[0] || '';

  const profileIncome = profile?.monthly_income || 0;
  const loggedIncome = monthIncomes.reduce((s, i) => s + i.amount, 0);
  const monthIncome = profileIncome + loggedIncome;
  const monthOutgoings = profile?.monthly_outgoings || 0;
  const monthSpent = monthExpenses.reduce((s, e) => s + e.amount, 0);
  const remaining = (monthIncome - monthOutgoings) - monthSpent;

  const todaySpent = todayExpenses.reduce((s, e) => s + e.amount, 0);
  const dailyBudget = profile?.daily_budget ?? null;

  const essentialTotal = monthExpenses.filter((e) => e.is_essential).reduce((s, e) => s + e.amount, 0);
  const avoidableExpenses = monthExpenses.filter((e) => !e.is_essential);
  const avoidableTotal = avoidableExpenses.reduce((s, e) => s + e.amount, 0);
  const essentialPct = monthSpent > 0 ? (essentialTotal / monthSpent) * 100 : 0;
  const avoidablePct = 100 - essentialPct;

  // Auto-calculated goal progress (this month's disposable savings)
  const disposableSaved = Math.max(0, (monthIncome - monthOutgoings) - monthSpent);

  const categoryTotals = Object.entries(
    monthExpenses.reduce((acc: Record<string, number>, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {})
  ).map(([cat, total]) => ({ cat: cat as Category, total })).sort((a, b) => b.total - a.total);

  const tip = getTodayTip(symbol, currencyCode);

  return (
    <div className="min-h-screen bg-page pb-28">
      {/* Nav */}
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Home</h1>
        </div>
      </nav>

      <div className="max-w-lg mx-auto px-4 pt-5 space-y-4">

        {/* Greeting */}
        <div className="bg-navy rounded-card shadow-card px-6 py-5 text-white">
          <p className="text-[12px] font-sans text-white/50 uppercase tracking-widest mb-1">{formatDayMonth()}</p>
          <h2 className="font-heading font-semibold text-[22px] leading-tight text-white mb-3">
            {getGreeting()}{firstName ? `, ${firstName}` : ''}
          </h2>
          <div className="bg-white/8 rounded-[10px] px-4 py-3">
            <p className="text-[11px] uppercase tracking-widest text-white/40 font-sans mb-2">Tip of the day</p>
            <p className="font-sans text-[13px] text-white font-medium leading-snug mb-1">{tip.action}</p>
            <p className="font-sans text-[12px] text-teal/90 leading-snug">— {tip.saving}</p>
          </div>
        </div>

        {/* Month snapshot */}
        <div>
          <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em] mb-2 px-0.5">This month</p>
          <div className="grid grid-cols-3 gap-3">
            {([
              { key: 'income' as const, label: 'Income', value: monthIncome, icon: Wallet, color: 'text-teal' },
              { key: 'spent' as const, label: 'Spent', value: monthSpent, icon: TrendingDown, color: 'text-red' },
              { key: 'remaining' as const, label: 'Remaining', value: remaining, icon: Target, color: remaining >= 0 ? 'text-teal' : 'text-red' },
            ]).map(({ key, label, value, icon: Icon, color }) => (
              <button
                key={key}
                onClick={() => setActiveDrawer(key)}
                className="bg-surface rounded-card shadow-card p-4 flex flex-col gap-2 text-left hover:shadow-md active:scale-[0.97] transition-all"
              >
                <div className={`w-7 h-7 rounded-[8px] flex items-center justify-center bg-page ${color}`}>
                  <Icon size={14} />
                </div>
                <div>
                  <p className="text-[11px] text-muted font-sans">{label}</p>
                  <p className={`font-sans font-semibold text-[14px] leading-tight ${color}`} style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatAmount(Math.abs(value), currencyCode)}
                  </p>
                </div>
                <p className="text-[10px] text-muted/60 font-sans">Tap for details</p>
              </button>
            ))}
          </div>
        </div>

        {/* Over-budget warning banner */}
        {remaining < 0 && (
          <div className="bg-red/5 border border-red/20 rounded-card px-4 py-3 flex items-start gap-3 animate-slide-up">
            <AlertTriangle size={16} className="text-red shrink-0 mt-0.5" />
            <div>
              <p className="font-sans font-semibold text-[13px] text-red">Be mindful — you're spending more than your budget.</p>
              <p className="font-sans text-[12px] text-red/80 mt-0.5">
                You're {formatAmount(Math.abs(remaining), currencyCode)} over this month. Review your avoidable spend to get back on track.
              </p>
            </div>
          </div>
        )}

        {/* My Goals */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading font-semibold text-navy text-[16px]">My goals</h3>
            <button
              onClick={() => { setEditingGoal(null); setShowGoalModal(true); }}
              className="flex items-center gap-1.5 text-[12px] font-semibold text-teal hover:opacity-80 transition-opacity"
            >
              <Plus size={14} /> Add goal
            </button>
          </div>

          {goals.length === 0 ? (
            <div className="py-4 text-center">
              <p className="text-[13px] text-muted font-sans mb-3">No goals set yet — add one to start tracking</p>
              <button
                onClick={() => { setEditingGoal(null); setShowGoalModal(true); }}
                className="px-4 py-2 bg-teal/10 text-teal rounded-btn text-[13px] font-semibold font-sans hover:bg-teal/20 transition-colors"
              >
                Add your first goal
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {goals.map((g) => (
                <GoalCard
                  key={g.id}
                  goal={g}
                  currencyCode={currencyCode}
                  symbol={symbol}
                  monthSpent={monthSpent}
                  disposableSaved={disposableSaved}
                  onDelete={handleDeleteGoal}
                  onEdit={(goal) => { setEditingGoal(goal); setShowGoalModal(true); }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Daily Budget */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading font-semibold text-navy text-[16px]">Daily budget</h3>
            {!editingBudget && (
              <button
                onClick={() => { setBudgetInput(dailyBudget ? String(dailyBudget) : ''); setEditingBudget(true); }}
                className="flex items-center gap-1.5 text-[12px] text-muted hover:text-slate transition-colors"
              >
                <Pencil size={13} />
                {dailyBudget ? 'Edit' : 'Set budget'}
              </button>
            )}
          </div>
          {editingBudget ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[20px] font-sans text-slate font-medium">{symbol}</span>
                <input type="number" value={budgetInput} onChange={(e) => setBudgetInput(e.target.value)}
                  placeholder="e.g. 50" autoFocus
                  className="flex-1 text-[20px] font-sans font-semibold text-navy bg-page rounded-input px-3 py-2 border border-border outline-none focus:border-teal transition-colors"
                  style={{ fontVariantNumeric: 'tabular-nums' }} />
              </div>
              <div className="flex gap-2">
                <button onClick={handleSaveBudget} disabled={savingBudget || !budgetInput}
                  className="flex-1 flex items-center justify-center gap-2 h-10 bg-teal text-white rounded-btn text-[14px] font-semibold font-sans hover:bg-opacity-90 transition-all disabled:opacity-40">
                  {savingBudget ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check size={15} /> Save</>}
                </button>
                {dailyBudget && (
                  <button onClick={handleClearBudget} className="h-10 px-4 flex items-center gap-1.5 border border-border rounded-btn text-[13px] text-muted hover:text-red hover:border-red/40 transition-colors">
                    <X size={13} /> Remove
                  </button>
                )}
                <button onClick={() => setEditingBudget(false)} className="h-10 px-4 border border-border rounded-btn text-[13px] text-muted hover:text-slate transition-colors">
                  Cancel
                </button>
              </div>
            </div>
          ) : dailyBudget ? (
            <BudgetRing spent={todaySpent} budget={dailyBudget} currencyCode={currencyCode} symbol={symbol} />
          ) : (
            <div className="py-4 text-center">
              <p className="text-[13px] text-muted font-sans">Set a daily spend limit to track your progress here</p>
            </div>
          )}
        </div>

        {/* This month's spending — dynamic clickable avoidable bar */}
        {monthSpent > 0 && (
          <div className="bg-surface rounded-card shadow-card p-5">
            <h3 className="font-heading font-semibold text-navy text-[16px] mb-3">This month's spending</h3>

            {/* The bar — avoidable section is a clickable button */}
            <div className="flex rounded-full overflow-hidden h-4 mb-3 cursor-default">
              <div
                className="bg-teal h-full transition-all duration-500"
                style={{ width: `${essentialPct}%` }}
                title={`Essential: ${formatAmount(essentialTotal, currencyCode)}`}
              />
              {avoidablePct > 0 && (
                <button
                  onClick={() => setShowAvoidable(true)}
                  className="bg-red h-full flex-1 hover:brightness-110 active:brightness-90 transition-all relative group"
                  style={{ width: `${avoidablePct}%` }}
                  title={`Avoidable: ${formatAmount(avoidableTotal, currencyCode)} — tap to review`}
                >
                  {avoidablePct > 12 && (
                    <span className="absolute inset-0 flex items-center justify-center text-white text-[10px] font-semibold font-sans opacity-0 group-hover:opacity-100 transition-opacity">
                      Review
                    </span>
                  )}
                </button>
              )}
            </div>

            <div className="flex justify-between items-center text-[12px] font-sans">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-teal" />
                <span className="text-muted">Essential</span>
                <span className="font-semibold text-slate ml-1">{formatAmount(essentialTotal, currencyCode)}</span>
              </div>
              <button
                onClick={() => setShowAvoidable(true)}
                className="flex items-center gap-1.5 hover:opacity-75 transition-opacity group"
              >
                <span className="font-semibold text-slate">{formatAmount(avoidableTotal, currencyCode)}</span>
                <span className="text-muted">Avoidable</span>
                <div className="w-2.5 h-2.5 rounded-full bg-red" />
                <ChevronRight size={13} className="text-muted group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

          </div>
        )}

        {/* Spend by category */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading font-semibold text-navy text-[16px]">Spend by category</h3>
            <button onClick={() => navigate('/dashboard')}
              className="text-[12px] text-teal font-sans font-medium hover:underline flex items-center gap-1">
              Full view <ChevronRight size={13} />
            </button>
          </div>
          {loadingExpenses ? (
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="h-3 bg-border rounded-full animate-pulse w-full" />
                  <div className="h-4 bg-border rounded animate-pulse w-12 shrink-0" />
                </div>
              ))}
            </div>
          ) : categoryTotals.length === 0 ? (
            <div className="py-6 text-center">
              <p className="text-[13px] text-muted font-sans">Nothing logged yet — tap + to add your first expense</p>
            </div>
          ) : (
            <div className="space-y-3">
              {categoryTotals.map(({ cat, total }) => {
                const color = CATEGORY_COLORS[cat];
                const pct = monthSpent > 0 ? (total / monthSpent) * 100 : 0;
                return (
                  <div key={cat}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                        <span className="font-sans text-[13px] text-slate">{cat}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-sans font-semibold text-[13px] text-navy" style={{ fontVariantNumeric: 'tabular-nums' }}>
                          {formatAmount(total, currencyCode)}
                        </span>
                        <span className="font-sans text-[11px] text-muted w-8 text-right">{Math.round(pct)}%</span>
                      </div>
                    </div>
                    <div className="w-full bg-border rounded-full h-1.5 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${pct}%`, backgroundColor: color }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <BottomNav />

      {/* Summary drawers for stat cards */}
      {activeDrawer && (
        <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={() => setActiveDrawer(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-lg bg-surface rounded-t-[24px] shadow-2xl max-h-[80vh] flex flex-col animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-border" />
            </div>
            <div className="px-5 pt-2 pb-4 border-b border-border flex items-center justify-between">
              <div>
                <h2 className="font-heading font-semibold text-navy text-[18px]">
                  {activeDrawer === 'income' && 'Monthly income'}
                  {activeDrawer === 'spent' && 'Monthly spending'}
                  {activeDrawer === 'remaining' && 'Remaining balance'}
                </h2>
                <p className="text-[12px] text-muted font-sans mt-0.5">
                  {new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}
                </p>
              </div>
              <button onClick={() => setActiveDrawer(null)} className="p-2 rounded-btn text-muted hover:text-slate transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 px-5 py-4 space-y-3">
              {activeDrawer === 'income' && (
                <>
                  {profileIncome > 0 && (
                    <div className="flex items-center justify-between py-3 border-b border-border">
                      <div>
                        <p className="font-sans font-medium text-[14px] text-slate">Monthly salary / base income</p>
                        <p className="font-sans text-[12px] text-muted">Set in Settings</p>
                      </div>
                      <span className="font-sans font-semibold text-[15px] text-teal" style={{ fontVariantNumeric: 'tabular-nums' }}>
                        +{formatAmount(profileIncome, currencyCode)}
                      </span>
                    </div>
                  )}
                  {monthIncomes.map((inc) => (
                    <div key={inc.id} className="flex items-center justify-between py-3 border-b border-border">
                      <div>
                        <p className="font-sans font-medium text-[14px] text-slate">{inc.description || inc.category}</p>
                        <p className="font-sans text-[12px] text-muted">{inc.category} · {new Date(inc.income_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</p>
                      </div>
                      <span className="font-sans font-semibold text-[15px] text-teal" style={{ fontVariantNumeric: 'tabular-nums' }}>
                        +{formatAmount(inc.amount, inc.currency_code)}
                      </span>
                    </div>
                  ))}
                  {profileIncome === 0 && monthIncomes.length === 0 && (
                    <p className="text-[13px] text-muted font-sans py-6 text-center">No income recorded — set your monthly income in Settings</p>
                  )}
                  <div className="flex items-center justify-between pt-3 border-t-2 border-border">
                    <p className="font-sans font-semibold text-[14px] text-navy">Total income</p>
                    <span className="font-sans font-bold text-[16px] text-teal" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {formatAmount(monthIncome, currencyCode)}
                    </span>
                  </div>
                </>
              )}
              {activeDrawer === 'spent' && (
                <>
                  {Object.entries(
                    monthExpenses.reduce((acc: Record<string, { total: number; count: number }>, e) => {
                      if (!acc[e.category]) acc[e.category] = { total: 0, count: 0 };
                      acc[e.category].total += e.amount;
                      acc[e.category].count += 1;
                      return acc;
                    }, {})
                  ).sort((a, b) => b[1].total - a[1].total).map(([cat, { total, count }]) => (
                    <div key={cat} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                      <div className="flex items-center gap-3">
                        <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: CATEGORY_COLORS[cat as Category] || '#6B7A8D' }} />
                        <div>
                          <p className="font-sans font-medium text-[14px] text-slate">{cat}</p>
                          <p className="font-sans text-[12px] text-muted">{count} transaction{count !== 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      <span className="font-sans font-semibold text-[15px] text-navy" style={{ fontVariantNumeric: 'tabular-nums' }}>
                        {formatAmount(total, currencyCode)}
                      </span>
                    </div>
                  ))}
                  {monthExpenses.length === 0 && (
                    <p className="text-[13px] text-muted font-sans py-6 text-center">No expenses logged this month</p>
                  )}
                  <div className="flex items-center justify-between pt-3 border-t-2 border-border">
                    <p className="font-sans font-semibold text-[14px] text-navy">Total spent</p>
                    <span className="font-sans font-bold text-[16px] text-red" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {formatAmount(monthSpent, currencyCode)}
                    </span>
                  </div>
                </>
              )}
              {activeDrawer === 'remaining' && (
                <>
                  <div className="flex items-center justify-between py-3 border-b border-border">
                    <div>
                      <p className="font-sans font-medium text-[14px] text-slate">Total income</p>
                      <p className="font-sans text-[12px] text-muted">Base salary + additional logged income</p>
                    </div>
                    <span className="font-sans font-semibold text-[15px] text-teal" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      +{formatAmount(monthIncome, currencyCode)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-border">
                    <div>
                      <p className="font-sans font-medium text-[14px] text-slate">Fixed outgoings</p>
                      <p className="font-sans text-[12px] text-muted">Bills, rent, subscriptions</p>
                    </div>
                    <span className="font-sans font-semibold text-[15px] text-red" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      −{formatAmount(monthOutgoings, currencyCode)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-border">
                    <div>
                      <p className="font-sans font-medium text-[14px] text-slate">Variable spend</p>
                      <p className="font-sans text-[12px] text-muted">{monthExpenses.length} expense{monthExpenses.length !== 1 ? 's' : ''} logged</p>
                    </div>
                    <span className="font-sans font-semibold text-[15px] text-red" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      −{formatAmount(monthSpent, currencyCode)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t-2 border-border">
                    <p className="font-sans font-semibold text-[14px] text-navy">Remaining</p>
                    <span className={`font-sans font-bold text-[16px] ${remaining >= 0 ? 'text-teal' : 'text-red'}`} style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {remaining >= 0 ? '' : '−'}{formatAmount(Math.abs(remaining), currencyCode)}
                    </span>
                  </div>
                  <div className="bg-page rounded-[10px] px-4 py-3 mt-1">
                    <p className="font-sans text-[12px] text-muted leading-relaxed">
                      <span className="font-semibold text-slate">Formula: </span>
                      Income ({formatAmount(monthIncome, currencyCode)}) − Outgoings ({formatAmount(monthOutgoings, currencyCode)}) − Spent ({formatAmount(monthSpent, currencyCode)}) = <span className={remaining >= 0 ? 'text-teal font-semibold' : 'text-red font-semibold'}>{formatAmount(remaining, currencyCode)}</span>
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showAvoidable && (
        <AvoidableDrawer expenses={avoidableExpenses} currencyCode={currencyCode}
          onClose={() => setShowAvoidable(false)} onSelectExpense={(id) => setSelectedExpenseId(id)} />
      )}

      {showGoalModal && user && (
        <GoalModal
          editingGoal={editingGoal}
          userId={user.id}
          currencyCode={currencyCode}
          symbol={symbol}
          onClose={() => { setShowGoalModal(false); setEditingGoal(null); }}
          onSaved={() => { setShowGoalModal(false); setEditingGoal(null); fetchGoals(); }}
        />
      )}

      {selectedExpenseId && (
        <ExpenseDetailModal expenseId={selectedExpenseId} currencyCode={currencyCode}
          onClose={() => setSelectedExpenseId(null)} onUpdate={fetchExpenses} />
      )}

      {celebratingGoal && (
        <CelebrationOverlay
          goal={celebratingGoal}
          onDismiss={() => setCelebratingGoal(null)}
        />
      )}
    </div>
  );
}