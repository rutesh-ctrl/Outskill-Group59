import { useState, useMemo } from 'react';
import { Search, Clock, Tag, ChevronDown, ChevronUp, X } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

interface Article {
  id: string;
  title: string;
  category: string;
  readTime: number;
  tag: string;
  summary: string;
  body: string[];
}

const ARTICLES: Article[] = [
  {
    id: 'budgeting-50-30-20',
    title: 'Budgeting Basics: The 50/30/20 Rule',
    category: 'Budgeting Basics',
    readTime: 3,
    tag: 'Start here',
    summary: 'Divide your after-tax income into three simple buckets — needs, wants, and savings.',
    body: [
      'The 50/30/20 rule is one of the most practical frameworks for everyday budgeting. After taxes, allocate 50% to needs (rent, groceries, utilities), 30% to wants (dining out, subscriptions, entertainment), and 20% to savings or debt repayment.',
      'Why it works: the rule is flexible enough to adapt to any income level, and simple enough that you don\'t need a spreadsheet. If your "needs" bucket is running over 50%, that\'s a signal to look at fixed costs like rent or car payments first.',
      'To start, look at last month\'s bank statement and categorise every transaction into one of the three buckets. Even if the numbers aren\'t perfect yet, awareness alone changes your spending behaviour.',
      'Pro tip: treat the 20% savings transfer like a bill — automate it on payday so it leaves before you can spend it.',
    ],
  },
  {
    id: 'emergency-fund',
    title: 'Building Your Emergency Fund',
    category: 'Emergency Funds',
    readTime: 4,
    tag: 'Essential',
    summary: 'An emergency fund is the single most important financial safety net you can build.',
    body: [
      'An emergency fund is 3–6 months of essential living expenses held in a separate, accessible savings account. It\'s not an investment — it\'s insurance against life\'s surprises: job loss, medical bills, car repairs, or a broken boiler.',
      'Without one, even a minor financial shock forces you into debt — often high-interest debt that takes years to clear. With one, the same event becomes a mild inconvenience.',
      'Start small. If 3 months feels impossibly far away, aim for one month first. Then two. Even a modest sum in a separate account provides meaningful protection against everyday emergencies.',
      'Keep it separate from your current account so it doesn\'t get accidentally spent. A high-interest easy-access savings account is ideal — you want your money earning interest but still available within a day.',
      'Once built, only touch it for genuine emergencies. A holiday is not an emergency. A new phone is not an emergency. A broken boiler in winter? That is.',
    ],
  },
  {
    id: 'impulse-spending',
    title: 'Avoiding Impulse Spending',
    category: 'Avoiding Impulse Spending',
    readTime: 3,
    tag: 'Behaviour',
    summary: 'The 48-hour rule and other proven techniques to pause before you buy.',
    body: [
      'Impulse spending is spending that wasn\'t planned before you started your day. Research shows 40–60% of purchases are impulse-driven, triggered by emotion, convenience, or marketing.',
      'The most effective technique is the 48-hour rule: when you feel the urge to buy something non-essential, save the item in a wishlist and wait 48 hours. You\'ll skip about 70% of those purchases — not through willpower, but because the desire genuinely passes.',
      'Other proven tactics: unsubscribe from marketing emails, delete shopping apps from your home screen (friction reduces purchases), never shop when hungry or emotionally stressed, and unfollow social accounts that consistently trigger buying urges.',
      'In Vera, every time you log an avoidable expense, you\'re building the awareness that is the foundation of better spending. Awareness alone reduces spending by around 15% on average.',
    ],
  },
  {
    id: 'managing-debt',
    title: 'Managing Debt: Avalanche vs Snowball',
    category: 'Managing Debt',
    readTime: 5,
    tag: 'Debt',
    summary: 'Two proven strategies for paying off debt faster — and which one suits you.',
    body: [
      'If you have multiple debts, there are two main repayment strategies: the avalanche and the snowball.',
      'Avalanche method: list all debts by interest rate, highest first. Make minimum payments on everything, and put any extra money towards the highest-interest debt. Mathematically, this saves the most money overall.',
      'Snowball method: list debts by balance, smallest first. Put extra money towards the smallest debt regardless of interest rate. When it\'s cleared, roll that payment onto the next. This method gives faster psychological wins — which matters for motivation.',
      'Which should you use? If you\'re motivated by numbers, use the avalanche. If you\'ve tried debt repayment before and given up, use the snowball. The best strategy is the one you actually stick to.',
      'One universal rule: always make at least the minimum payment on every debt, every month. Missed payments damage your credit score and often trigger penalty interest rates.',
    ],
  },
  {
    id: 'saving-money',
    title: '10 Ways to Save More This Month',
    category: 'Saving Money',
    readTime: 4,
    tag: 'Practical',
    summary: 'Small changes that compound into meaningful savings without feeling deprived.',
    body: [
      '1. Automate savings on payday. Move money out before you can spend it.',
      '2. Meal plan before grocery shopping. Write a list and stick to it — unplanned supermarket trips are where budgets break down.',
      '3. Audit your subscriptions. The average household has 12 active subscriptions and forgets about half. Cancel anything unused in 30 days.',
      '4. Switch to own-brand on staples. Flour, pasta, rice, washing powder — typically 30–40% cheaper with no meaningful quality difference.',
      '5. Renegotiate bills at renewal. Loyalty is penalised in most industries. Call at renewal and ask for the new customer rate.',
      '6. Batch-cook on weekends. One session produces 4–5 meals. You save money and avoid the "can\'t be bothered to cook" takeaway.',
      '7. Use cashback apps and browser extensions. Passive savings on things you were going to buy anyway.',
      '8. Track every spend for one week. Most people underestimate their spending by 30–40%. Seeing the real number is often motivation enough.',
    ],
  },
  {
    id: 'financial-habits',
    title: 'The Financial Habits That Actually Matter',
    category: 'Financial Habits',
    readTime: 4,
    tag: 'Mindset',
    summary: 'Sustainable financial health is built on consistent small habits, not dramatic overhauls.',
    body: [
      'Most financial advice focuses on the dramatic: quit lattes, sell your car, move somewhere cheaper. But sustainable financial health is built through boring, consistent small habits compounded over time.',
      'The habits that actually move the needle: reviewing your spending weekly (15 minutes), saving before spending rather than after, reviewing subscriptions quarterly, reading one bank statement per month, and setting a specific savings goal rather than a vague intention.',
      'Weekly reviews are the most underrated habit. 10 minutes scrolling through transactions will catch subscriptions you forgot about, reveal spending patterns, and keep you connected to where your money goes.',
      'Financial anxiety often comes not from having too little money, but from not knowing where it goes. The moment you start tracking — even imperfectly — anxiety often reduces because you feel in control.',
    ],
  },
  {
    id: 'needs-vs-wants',
    title: 'Understanding Needs vs Wants',
    category: 'Understanding Needs vs Wants',
    readTime: 3,
    tag: 'Awareness',
    summary: 'The classic distinction — and why it\'s harder in practice than it sounds.',
    body: [
      'Needs are things you genuinely cannot function without: shelter, food, utilities, transport to work, medication. Wants are everything else.',
      'In practice, the line is blurry. Is a smartphone a need? For most people today, yes. Is the latest model a need? Almost certainly not. Is eating out a need? No. Is cooking at home a need? Yes.',
      'The useful question is not "is this technically a need" but "would I be genuinely unable to function without this, or am I rationalising?" Most of us are excellent at rationalising.',
      'A simple test: could I go without this for one month without serious consequences? If yes, it\'s probably a want. In Vera, the Essential/Avoidable classification is your personal version of this — there\'s no judgement, just honest self-awareness.',
    ],
  },
  {
    id: 'subscriptions',
    title: 'Getting Control of Subscriptions',
    category: 'Subscription Management',
    readTime: 3,
    tag: 'Quick win',
    summary: 'The average person pays for subscriptions they\'ve forgotten. Here\'s how to audit.',
    body: [
      'Subscription services are designed to be forgettable — that\'s part of the business model. A small recurring charge is easy to miss, especially when multiplied across many services.',
      'The average household spends significantly on subscriptions annually, and research suggests roughly 40% go largely unused.',
      'How to audit: go through the last three months of bank statements and highlight every recurring payment. For each one, ask: have I used this in the last 30 days? If no, cancel now. If yes, ask: am I getting value worth the cost?',
      'Common forgotten subscriptions: free trials that converted to paid, duplicate streaming services, premium tiers of apps you use for free, annual subscriptions that auto-renewed, gym memberships you stopped using.',
      'After cancelling, set a calendar reminder one month from now. You\'ll find you don\'t miss most of them.',
    ],
  },
  {
    id: 'meal-planning',
    title: 'Meal Planning to Cut Food Costs',
    category: 'Meal Planning to Save Money',
    readTime: 4,
    tag: 'Practical',
    summary: 'Food is typically the easiest budget category to reduce without affecting quality of life.',
    body: [
      'Food spending is often the most controllable large budget category. Unlike rent or utility bills, it responds immediately to behaviour change — and the changes don\'t require sacrifice, just planning.',
      'The biggest single lever: plan meals before you shop. Unplanned supermarket trips lead to buying things you don\'t need and later throw away. A weekly meal plan — even a rough one — dramatically reduces food waste and impulse purchases.',
      'Batch cooking on weekends turns one hour of effort into multiple weekday lunches or dinners. A large pot of soup, a tray of roasted vegetables, or a big batch of grains can underpin several meals through the week.',
      'The cost ratio of eating out versus cooking at home is typically 3:1 or higher. One restaurant meal often costs what four home-cooked meals would. This doesn\'t mean never eating out — it means understanding the real cost.',
    ],
  },
  {
    id: 'weekly-challenges',
    title: 'Weekly Budget Challenges',
    category: 'Weekly Budget Challenges',
    readTime: 2,
    tag: 'Challenge',
    summary: 'Seven micro-challenges to build financial awareness and save a little extra.',
    body: [
      'Week 1 — No Spend Days: aim for two days this week where you spend nothing at all. Pack lunch, make coffee at home, skip the evening snack run.',
      'Week 2 — Subscription Audit: find and cancel at least one subscription you no longer need. Redirect that money to savings.',
      'Week 3 — Meal Plan Week: plan every meal before you shop. Track how much you saved versus a typical week.',
      'Week 4 — 48-Hour Rule: every non-essential purchase this week must wait 48 hours before you buy it.',
      'Week 5 — Statement Review: sit down with last month\'s statement and highlight the three expenses you most regret. Plan how to avoid each one next month.',
      'Week 6 — Renegotiate One Bill: call one provider at renewal and ask for a better rate. Even a 10% reduction adds up over a year.',
      'Week 7 — Energy Audit: check utility settings, smart thermostat schedules, and standby devices. Small changes here save money all year round.',
    ],
  },
  {
    id: 'smart-spending',
    title: 'Smart Spending: More Value from Every Pound',
    category: 'Smart Spending Tips',
    readTime: 3,
    tag: 'Tips',
    summary: 'Practical strategies to stretch every pound further without feeling restricted.',
    body: [
      'Smart spending isn\'t about deprivation — it\'s about getting maximum value from every pound you choose to spend.',
      'Price per use is the most useful mental model. A quality item you use 200 times costs far less per use than a cheap one you use 5 times. Cheap is not always good value.',
      'Buy experiences over things. Research shows experiences provide longer-lasting happiness than possessions — and experiences tend to be cheaper when shared.',
      'Timing matters. January sales, end-of-season clothing, and supermarket yellow-sticker sections all offer genuine savings. Price-tracking browser extensions let you know whether a "sale" price is actually a deal.',
      'Use what you have. Before buying something new, check whether you already own something that could serve the same purpose. This sounds obvious but most people skip the check.',
    ],
  },
];

const ALL_CATEGORIES = [...new Set(ARTICLES.map((a) => a.category))];

function ArticleCard({ article, onOpen }: { article: Article; onOpen: () => void }) {
  return (
    <button
      onClick={onOpen}
      className="w-full text-left bg-surface rounded-card shadow-card p-5 hover:shadow-md active:scale-[0.99] transition-all group"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex gap-2 flex-wrap">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal/10 text-teal">
            <Tag size={10} /> {article.tag}
          </span>
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-page text-muted border border-border">
            {article.category}
          </span>
        </div>
        <span className="flex items-center gap-1 text-[11px] text-muted font-sans shrink-0 mt-0.5">
          <Clock size={11} /> {article.readTime} min
        </span>
      </div>
      <h3 className="font-heading font-semibold text-navy text-[15px] mb-1.5 leading-snug group-hover:text-teal transition-colors">
        {article.title}
      </h3>
      <p className="font-sans text-[13px] text-muted leading-relaxed line-clamp-2">
        {article.summary}
      </p>
    </button>
  );
}

function ArticleModal({ article, onClose }: { article: Article; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-navy/40 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg bg-surface rounded-t-[24px] sm:rounded-card shadow-2xl max-h-[90vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drag handle (mobile) */}
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-border" />
        </div>
        {/* Header */}
        <div className="px-6 pt-4 pb-4 border-b border-border flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex gap-2 flex-wrap mb-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal/10 text-teal">
                <Tag size={10} /> {article.tag}
              </span>
              <span className="flex items-center gap-1 text-[11px] text-muted font-sans">
                <Clock size={11} /> {article.readTime} min read
              </span>
            </div>
            <h2 className="font-heading font-semibold text-navy text-[18px] leading-snug">{article.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-btn text-muted hover:text-slate hover:bg-border/50 transition-colors shrink-0"
          >
            <X size={20} />
          </button>
        </div>
        {/* Body */}
        <div className="overflow-y-auto flex-1 px-6 py-5">
          <p className="font-sans text-[14px] text-teal font-medium leading-relaxed mb-5 italic">
            {article.summary}
          </p>
          <div className="space-y-4">
            {article.body.map((para, i) => (
              <p key={i} className="font-sans text-[14px] text-slate leading-[1.75]">
                {para}
              </p>
            ))}
          </div>
        </div>
        {/* Footer */}
        <div className="px-6 pb-6 pt-3 border-t border-border">
          <button
            onClick={onClose}
            className="w-full h-11 bg-navy text-white rounded-btn text-[14px] font-semibold font-sans hover:bg-opacity-90 transition-all"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Learn() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [openArticle, setOpenArticle] = useState<Article | null>(null);
  const [expandedCats, setExpandedCats] = useState<Record<string, boolean>>({});

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return ARTICLES.filter((a) => {
      const matchesSearch =
        !q ||
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        a.tag.toLowerCase().includes(q);
      const matchesCat = !activeCategory || a.category === activeCategory;
      return matchesSearch && matchesCat;
    });
  }, [search, activeCategory]);

  const featuredArticle = ARTICLES[0];
  const showingAll = !search && !activeCategory;

  const toggleCat = (cat: string) =>
    setExpandedCats((prev) => ({ ...prev, [cat]: !prev[cat] }));

  return (
    <div className="min-h-screen bg-page pb-28">
      {/* Nav */}
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Learn</h1>
        </div>
      </nav>

      <div className="max-w-lg mx-auto px-4 pt-5 space-y-5">

        {/* Hero banner */}
        <div className="bg-navy rounded-card shadow-card px-6 py-5">
          <p className="text-[11px] font-sans text-white/50 uppercase tracking-[0.12em] mb-1.5">
            Financial education
          </p>
          <h2 className="font-heading font-semibold text-white text-[20px] leading-snug mb-1">
            Build better money habits
          </h2>
          <p className="font-sans text-[13px] text-white/60 leading-relaxed">
            Short, practical guides — written for real people, not finance textbooks.
          </p>
        </div>

        {/* Featured article */}
        {showingAll && (
          <div>
            <p className="text-[11px] font-sans text-muted uppercase tracking-[0.12em] mb-3">Featured</p>
            <button
              onClick={() => setOpenArticle(featuredArticle)}
              className="w-full text-left bg-white border-l-[3px] border-l-teal border border-teal/20 rounded-card shadow-card p-5 hover:bg-teal/4 active:scale-[0.99] transition-all group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-sans font-semibold text-teal uppercase tracking-[0.12em]">
                  START HERE
                </span>
                <span className="flex items-center gap-1 text-[11px] text-muted font-sans">
                  <Clock size={11} /> {featuredArticle.readTime} min
                </span>
              </div>
              <h3 className="font-heading font-semibold text-navy text-[16px] mb-1.5 group-hover:text-teal transition-colors">
                {featuredArticle.title}
              </h3>
              <p className="font-sans text-[13px] text-muted leading-relaxed">
                {featuredArticle.summary}
              </p>
            </button>
          </div>
        )}

        {/* Search */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search articles..."
            className="w-full h-11 pl-10 pr-4 border border-border rounded-[12px] text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
          />
        </div>

        {/* Category filter chips */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-3 py-1.5 rounded-full text-[12px] font-semibold font-sans transition-all ${
              !activeCategory
                ? 'bg-navy text-white'
                : 'bg-surface border border-border text-muted hover:border-steel/40'
            }`}
          >
            All
          </button>
          {ALL_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(activeCategory === cat ? null : cat)}
              className={`px-3 py-1.5 rounded-full text-[12px] font-semibold font-sans transition-all ${
                activeCategory === cat
                  ? 'bg-teal text-white'
                  : 'bg-surface border border-border text-muted hover:border-teal/40'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results / grouped list */}
        {!showingAll ? (
          <div>
            <p className="text-[12px] text-muted font-sans mb-3">
              {filtered.length} article{filtered.length !== 1 ? 's' : ''} found
            </p>
            {filtered.length === 0 ? (
              <div className="py-10 text-center">
                <p className="text-[14px] text-muted font-sans">No articles match — try a different search.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map((a) => (
                  <ArticleCard key={a.id} article={a} onOpen={() => setOpenArticle(a)} />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {ALL_CATEGORIES.filter((cat) => cat !== featuredArticle.category).map((cat) => {
              const catArticles = ARTICLES.filter((a) => a.category === cat);
              const expanded = expandedCats[cat] ?? false;
              const shown = expanded ? catArticles : catArticles.slice(0, 1);

              return (
                <div key={cat} className="bg-surface rounded-card shadow-card overflow-hidden">
                  <button
                    onClick={() => toggleCat(cat)}
                    className="w-full flex items-center justify-between px-5 py-4 hover:bg-page/60 transition-colors"
                  >
                    <div className="text-left">
                      <p className="font-heading font-semibold text-navy text-[14px]">{cat}</p>
                      <p className="font-sans text-[12px] text-muted mt-0.5">
                        {catArticles.length} article{catArticles.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                    {expanded
                      ? <ChevronUp size={16} className="text-muted" />
                      : <ChevronDown size={16} className="text-muted" />
                    }
                  </button>
                  {shown.map((a) => (
                    <div key={a.id} className="border-t border-border">
                      <button
                        onClick={() => setOpenArticle(a)}
                        className="w-full text-left px-5 py-4 hover:bg-page/60 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="font-sans font-medium text-[14px] text-slate leading-snug mb-0.5">
                              {a.title}
                            </p>
                            <p className="font-sans text-[12px] text-muted line-clamp-1 leading-snug">
                              {a.summary}
                            </p>
                          </div>
                          <span className="flex items-center gap-1 text-[11px] text-muted font-sans shrink-0 mt-0.5">
                            <Clock size={10} /> {a.readTime}m
                          </span>
                        </div>
                      </button>
                    </div>
                  ))}
                  {catArticles.length > 1 && (
                    <div className="border-t border-border">
                      <button
                        onClick={() => toggleCat(cat)}
                        className="w-full py-3 text-[12px] font-semibold text-teal font-sans hover:opacity-80 transition-opacity"
                      >
                        {expanded ? 'Show less' : `+ ${catArticles.length - 1} more`}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {openArticle && (
        <ArticleModal article={openArticle} onClose={() => setOpenArticle(null)} />
      )}

      <BottomNav />
    </div>
  );
}
