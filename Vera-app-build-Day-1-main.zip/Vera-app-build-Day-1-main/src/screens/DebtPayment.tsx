import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, Check, AlertTriangle, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { formatAmount, toISODateString, getMonthStart } from '../lib/currency';
import { UserGoal } from '../lib/types';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

export default function DebtPayment() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const amountRef = useRef<HTMLInputElement>(null);

  const [debtGoals, setDebtGoals] = useState<UserGoal[]>([]);
  const [selectedGoalId, setSelectedGoalId] = useState<string>('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(toISODateString(new Date()));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  // Financial context for validation
  const [remaining, setRemaining] = useState<number | null>(null);

  const currencyCode = profile?.currency_code || 'GBP';
  const symbol = profile?.currency_symbol || '£';

  const selectedGoal = debtGoals.find((g) => g.id === selectedGoalId) ?? null;
  const outstandingDebt = selectedGoal
    ? Math.max(0, (selectedGoal.target_amount ?? 0) - (selectedGoal.current_amount ?? 0))
    : null;

  const fetchData = useCallback(async () => {
    if (!user) return;

    // Fetch active clear_debt goals
    const { data: goalsData } = await supabase
      .from('user_goals')
      .select('*')
      .eq('user_id', user.id)
      .eq('goal_type', 'clear_debt')
      .eq('is_active', true)
      .order('created_at', { ascending: true });

    const goals = (goalsData as UserGoal[]) || [];
    setDebtGoals(goals);
    if (goals.length > 0 && !selectedGoalId) {
      setSelectedGoalId(goals[0].id);
    }

    // Calculate remaining budget for this month
    const monthStr = toISODateString(getMonthStart(new Date()));
    const [{ data: expData }, { data: incData }] = await Promise.all([
      supabase
        .from('expenses')
        .select('amount')
        .eq('user_id', user.id)
        .gte('expense_date', monthStr),
      supabase
        .from('income')
        .select('amount')
        .eq('user_id', user.id)
        .gte('income_date', monthStr),
    ]);

    const monthSpent = ((expData as { amount: number }[]) || []).reduce((s, e) => s + e.amount, 0);
    const loggedIncome = ((incData as { amount: number }[]) || []).reduce((s, i) => s + i.amount, 0);
    const effectiveIncome = (profile?.monthly_income || 0) + loggedIncome;
    const rem = (effectiveIncome - (profile?.monthly_outgoings || 0)) - monthSpent;
    setRemaining(rem);
  }, [user, profile, selectedGoalId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    amountRef.current?.focus();
  }, []);

  const validate = (): string => {
    const parsed = parseFloat(amount);
    if (isNaN(parsed) || parsed <= 0) return 'Please enter a valid amount greater than zero.';
    if (!selectedGoal) return 'Please select a debt goal.';
    if (outstandingDebt !== null && parsed > outstandingDebt) {
      return `Payment of ${formatAmount(parsed, currencyCode)} exceeds outstanding debt of ${formatAmount(outstandingDebt, currencyCode)}.`;
    }
    if (remaining !== null && parsed > remaining) {
      return `Payment of ${formatAmount(parsed, currencyCode)} exceeds your remaining budget of ${formatAmount(remaining, currencyCode)} this month.`;
    }
    return '';
  };

  const handleSave = async () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    const parsed = parseFloat(amount);
    setSaving(true);
    setError('');

    try {
      // 1. Insert expense record (category Bills, essential = true)
      const { error: expError } = await supabase.from('expenses').insert({
        user_id: user!.id,
        amount: parsed,
        currency_code: currencyCode,
        description: note.trim() || `Debt payment — ${selectedGoal!.label}`,
        category: 'Bills',
        is_essential: true,
        raw_input: note.trim() || `Debt payment ${parsed}`,
        ai_confidence: 1,
        micro_reaction: '',
        expense_date: date,
      });
      if (expError) throw expError;

      // 2. Update goal progress (add payment to current_amount)
      const newAmount = (selectedGoal!.current_amount || 0) + parsed;
      const { error: goalError } = await supabase
        .from('user_goals')
        .update({ current_amount: newAmount })
        .eq('id', selectedGoal!.id);
      if (goalError) throw goalError;

      setSaved(true);
      setTimeout(() => navigate('/'), 1400);
    } catch {
      setError('Something went wrong — please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (saved) {
    return (
      <div className="min-h-screen bg-page flex items-center justify-center">
        <div className="text-center space-y-3 animate-slide-up">
          <div className="w-16 h-16 rounded-full bg-teal/10 flex items-center justify-center mx-auto">
            <Check size={32} className="text-teal" />
          </div>
          <p className="font-heading font-semibold text-navy text-[18px]">Payment logged</p>
          <p className="font-sans text-[13px] text-muted">Debt goal updated</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-page pb-28">
      {/* Nav */}
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <button
            onClick={() => navigate(-1)}
            className="p-2 rounded-btn hover:bg-border/50 transition-colors text-navy mr-1"
          >
            <ArrowLeft size={20} />
          </button>
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Debt Payment</h1>
        </div>
      </nav>

      <div className="max-w-lg mx-auto">
        <div className="px-4 pt-5 space-y-4">
          {/* No debt goals banner */}
          {debtGoals.length === 0 && (
            <div className="bg-[#FFF8EC] border-l-[3px] border-l-amber border border-amber/20 rounded-card px-4 py-4 flex items-start gap-3">
              <AlertTriangle size={16} className="text-amber shrink-0 mt-0.5" />
              <div>
                <p className="font-sans font-semibold text-[13px] text-slate">No debt goal found</p>
                <p className="font-sans text-[12px] text-muted mt-0.5">
                  Add a "Clear debt" goal from the Home screen first so Vera can track your progress.
                </p>
                <button
                  onClick={() => navigate('/')}
                  className="mt-2 text-[12px] font-semibold text-teal hover:underline inline-block"
                >
                  Go to Home
                </button>
              </div>
            </div>
          )}

          {/* Debt goal selector */}
          {debtGoals.length > 0 && (
            <div className="bg-surface rounded-card shadow-card p-5 space-y-4">
              <div>
                <label className="block text-[12px] font-semibold text-muted uppercase tracking-wider font-sans mb-2">
                  Debt Goal
                </label>
                {debtGoals.length === 1 ? (
                  <div className="flex items-center gap-3 px-4 py-3 bg-page rounded-btn border border-border">
                    <CreditCard size={16} className="text-navy shrink-0" />
                    <span className="font-sans text-[14px] text-navy font-medium">{selectedGoal?.label}</span>
                  </div>
                ) : (
                  <div className="relative">
                    <select
                      value={selectedGoalId}
                      onChange={(e) => setSelectedGoalId(e.target.value)}
                      className="w-full h-11 pl-4 pr-10 border border-border rounded-input text-[14px] font-sans text-slate bg-white appearance-none focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
                    >
                      {debtGoals.map((g) => (
                        <option key={g.id} value={g.id}>{g.label}</option>
                      ))}
                    </select>
                    <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
                  </div>
                )}
              </div>

              {/* Outstanding debt summary */}
              {selectedGoal && selectedGoal.target_amount && (
                <div className="bg-page rounded-[10px] px-4 py-3 grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-[10px] text-muted uppercase tracking-wider font-sans mb-0.5">Total Debt</p>
                    <p className="font-sans font-semibold text-[14px] text-navy" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {formatAmount(selectedGoal.target_amount, currencyCode)}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted uppercase tracking-wider font-sans mb-0.5">Paid Off</p>
                    <p className="font-sans font-semibold text-[14px] text-teal" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {formatAmount(selectedGoal.current_amount || 0, currencyCode)}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted uppercase tracking-wider font-sans mb-0.5">Remaining</p>
                    <p className="font-sans font-semibold text-[14px] text-red" style={{ fontVariantNumeric: 'tabular-nums' }}>
                      {formatAmount(outstandingDebt ?? 0, currencyCode)}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Payment form */}
          <div className="bg-surface rounded-card shadow-card p-5 space-y-4">
            {/* Amount */}
            <div>
              <label className="block text-[12px] font-semibold text-muted uppercase tracking-wider font-sans mb-2">
                Payment Amount
              </label>
              <div className="flex items-center gap-2 h-14 px-4 border border-border rounded-input bg-white focus-within:ring-2 focus-within:ring-teal transition-shadow">
                <span className="font-sans text-[20px] text-muted">{symbol}</span>
                <input
                  ref={amountRef}
                  type="number"
                  value={amount}
                  onChange={(e) => { setAmount(e.target.value); setError(''); }}
                  placeholder="0.00"
                  min="0"
                  step="any"
                  className="flex-1 text-[22px] font-sans font-semibold text-navy bg-transparent focus:outline-none placeholder-border"
                  style={{ fontVariantNumeric: 'tabular-nums' }}
                />
              </div>

              {/* Quick-amount helpers when outstanding debt is known */}
              {outstandingDebt !== null && outstandingDebt > 0 && (
                <div className="flex gap-2 mt-2 flex-wrap">
                  {[
                    { label: 'Min', value: Math.max(1, Math.round(outstandingDebt * 0.05)) },
                    { label: '25%', value: Math.round(outstandingDebt * 0.25) },
                    { label: '50%', value: Math.round(outstandingDebt * 0.5) },
                    { label: 'Full', value: outstandingDebt },
                  ]
                    .filter((q) =>
                      q.value > 0 &&
                      (remaining === null || q.value <= remaining) &&
                      q.value <= outstandingDebt
                    )
                    .map((q) => (
                      <button
                        key={q.label}
                        onClick={() => { setAmount(String(q.value)); setError(''); }}
                        className="px-3 py-1.5 bg-page border border-border rounded-full text-[12px] font-sans text-slate hover:border-teal hover:text-teal transition-colors"
                      >
                        {q.label} ({formatAmount(q.value, currencyCode)})
                      </button>
                    ))}
                </div>
              )}
            </div>

            {/* Note */}
            <div>
              <label className="block text-[12px] font-semibold text-muted uppercase tracking-wider font-sans mb-2">
                Note <span className="font-normal normal-case text-muted/60">(optional)</span>
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. Credit card minimum payment"
                className="w-full h-11 px-4 border border-border rounded-input text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              />
            </div>

            {/* Date */}
            <div>
              <label className="block text-[12px] font-semibold text-muted uppercase tracking-wider font-sans mb-2">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full h-11 px-4 border border-border rounded-input text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              />
            </div>

            {/* Remaining budget context */}
            {remaining !== null && (
              <div className={`flex items-center gap-2 px-3 py-2.5 rounded-[10px] text-[12px] font-sans ${
                remaining >= 0 ? 'bg-ai-bg text-teal' : 'bg-red/5 text-red'
              }`}>
                <AlertTriangle size={13} className="shrink-0" />
                <span>
                  {remaining >= 0
                    ? `Remaining budget this month: ${formatAmount(remaining, currencyCode)}`
                    : `You are ${formatAmount(Math.abs(remaining), currencyCode)} over budget this month`}
                </span>
              </div>
            )}

            {error && (
              <div className="flex items-start gap-2 px-3 py-2.5 rounded-[10px] bg-red/5 border border-red/20 text-[12px] font-sans text-red">
                <AlertTriangle size={13} className="shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            <button
              onClick={handleSave}
              disabled={saving || debtGoals.length === 0}
              className="w-full h-[52px] bg-teal text-white rounded-[12px] text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-40 active:scale-[0.98]"
            >
              {saving
                ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : <><CreditCard size={16} /> Log payment</>}
            </button>
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
