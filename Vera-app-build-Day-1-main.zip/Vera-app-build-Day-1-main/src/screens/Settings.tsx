import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, LogOut, Check, Pencil, HelpCircle, X, ChevronDown, PiggyBank, TrendingDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { GOAL_LABELS, CURRENCIES } from '../lib/types';
import { formatAmount } from '../lib/currency';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

interface HelpItem {
  question: string;
  answer: string;
}

const HELP_ITEMS: HelpItem[] = [
  {
    question: 'How is my monthly income calculated?',
    answer: 'Your total monthly income is the sum of your base salary (set in Settings) plus any additional income entries you log during the month (e.g. freelance payments, gifts, investments). Both sources are always added together to give you an accurate picture.',
  },
  {
    question: 'What is the difference between Spent and Remaining?',
    answer: '"Spent" shows the total of all expenses you have logged this month. "Remaining" is your disposable balance: Total Income minus Fixed Outgoings minus Variable Spending. A negative remaining means your recorded outflows exceed your income.',
  },
  {
    question: 'What are Fixed Outgoings?',
    answer: 'Fixed outgoings are your recurring committed costs — rent, mortgage, loan repayments, regular bills, and subscriptions. You set this figure during onboarding. These are deducted from your income before variable spending to give a realistic remaining balance.',
  },
  {
    question: 'What is the difference between Essential and Avoidable spend?',
    answer: 'When you log an expense, you choose whether it is essential (groceries, medicine, transport to work) or avoidable (takeaways, impulse purchases, unused subscriptions). The split is shown in the spending bar on the home screen. Tapping the red section lets you review your avoidable spend by category.',
  },
  {
    question: 'How does the Daily Budget ring work?',
    answer: 'The daily budget ring shows how much of your chosen daily spend limit you have used today. The ring turns amber at 75% and red when you go over. You can set or update your daily budget from the Home screen.',
  },
  {
    question: 'How do Goals work?',
    answer: 'Goals let you set a financial target — such as saving a specific amount, reducing spending, or clearing debt. Progress is calculated automatically each month based on your disposable balance. When you reach 100% of a target, you get a celebration moment.',
  },
  {
    question: 'How does the AI insight on the Dashboard work?',
    answer: 'Once a day, the app generates a personalised insight based on your week\'s spending data and your stated goal. It is produced by an AI model and is designed to be direct and actionable, not generic. The insight is cached for the day so it loads instantly on repeat visits.',
  },
  {
    question: 'Can I log income in a different currency?',
    answer: 'Income entries use your selected app currency. To change your currency go to Settings and tap Change next to Currency. Note that changing currency does not convert historical data — it only affects new entries.',
  },
  {
    question: 'How do I delete or edit an expense?',
    answer: 'Tap any expense in the list to open the detail view. From there you can edit the description, amount, category, date, or essential/avoidable status, and also delete the entry entirely.',
  },
  {
    question: 'Is my financial data private?',
    answer: 'Your data is stored securely in a Supabase database with Row Level Security — only your own account can read or write your records. No financial data is shared with third parties. The AI insight is generated using your aggregate spending numbers only, never individual transaction details.',
  },
];

function HelpAccordion({ items }: { items: HelpItem[] }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="divide-y divide-border">
      {items.map((item, i) => (
        <div key={i}>
          <button
            className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-page/60 transition-colors"
            onClick={() => setOpen(open === i ? null : i)}
          >
            <p className="font-sans font-medium text-[14px] text-navy pr-4 leading-snug">{item.question}</p>
            <ChevronDown
              size={16}
              className={`text-muted shrink-0 transition-transform duration-200 ${open === i ? 'rotate-180' : ''}`}
            />
          </button>
          {open === i && (
            <div className="px-6 pb-4">
              <p className="font-sans text-[13px] text-slate leading-relaxed">{item.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default function Settings() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const [signingOut, setSigningOut] = useState(false);

  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [savingName, setSavingName] = useState(false);

  const [editingIncome, setEditingIncome] = useState(false);
  const [incomeInput, setIncomeInput] = useState('');
  const [savingIncome, setSavingIncome] = useState(false);

  const [showHelp, setShowHelp] = useState(false);

  const [editingCurrency, setEditingCurrency] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(profile?.currency_code || 'GBP');
  const [savingCurrency, setSavingCurrency] = useState(false);

  const [editingAllocation, setEditingAllocation] = useState(false);
  const [selectedAllocation, setSelectedAllocation] = useState<'apply_to_debt' | 'keep_as_savings' | null>(
    profile?.savings_allocation ?? null
  );
  const [savingAllocation, setSavingAllocation] = useState(false);

  const handleSaveCurrency = async () => {
    if (!user) return;
    const currency = CURRENCIES.find((c) => c.code === selectedCurrency);
    if (!currency) return;
    setSavingCurrency(true);
    await supabase
      .from('user_profiles')
      .update({ currency_code: currency.code, currency_symbol: currency.symbol })
      .eq('user_id', user.id);
    await refreshProfile();
    setSavingCurrency(false);
    setEditingCurrency(false);
  };

  const handleSaveAllocation = async () => {
    if (!user || !selectedAllocation) return;
    setSavingAllocation(true);
    await supabase
      .from('user_profiles')
      .update({ savings_allocation: selectedAllocation })
      .eq('user_id', user.id);
    await refreshProfile();
    setSavingAllocation(false);
    setEditingAllocation(false);
  };

  const goalLabel = profile?.goal
    ? GOAL_LABELS[profile.goal as keyof typeof GOAL_LABELS] || profile.goal
    : '—';

  const handleSignOut = async () => {
    setSigningOut(true);
    await supabase.auth.signOut();
    navigate('/auth');
  };

  const handleSaveIncome = async () => {
    if (!user) return;
    const val = parseFloat(incomeInput);
    if (isNaN(val) || val < 0) return;
    setSavingIncome(true);
    await supabase
      .from('user_profiles')
      .update({ monthly_income: val })
      .eq('user_id', user.id);
    await refreshProfile();
    setSavingIncome(false);
    setEditingIncome(false);
  };

  const handleSaveName = async () => {
    if (!user) return;
    const trimmed = nameInput.trim();
    setSavingName(true);
    await supabase
      .from('user_profiles')
      .update({ display_name: trimmed || null })
      .eq('user_id', user.id);
    await refreshProfile();
    setSavingName(false);
    setEditingName(false);
  };

  return (
    <div className="min-h-screen bg-page pb-28">
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Settings</h1>
        </div>
      </nav>

      <div className="max-w-lg mx-auto px-4 pt-6 space-y-4">

        {/* Your name */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em]">Your name</p>
          </div>
          <div className="px-6 py-4">
            {editingName ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="First name"
                  autoFocus
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSaveName(); if (e.key === 'Escape') setEditingName(false); }}
                  className="flex-1 font-sans text-[15px] text-slate bg-page rounded-input px-3 py-2 border border-border outline-none focus:border-teal transition-colors"
                />
                <button
                  onClick={handleSaveName}
                  disabled={savingName}
                  className="h-9 px-4 bg-teal text-white rounded-btn text-[13px] font-semibold font-sans flex items-center gap-1.5 hover:bg-opacity-90 transition-all disabled:opacity-40"
                >
                  {savingName ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check size={13} /> Save</>}
                </button>
                <button
                  onClick={() => setEditingName(false)}
                  className="h-9 px-3 border border-border rounded-btn text-[13px] text-muted hover:text-slate transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <p className="font-sans font-semibold text-[18px] text-navy">
                  {profile?.display_name || <span className="text-muted text-[15px] font-medium">Not set</span>}
                </p>
                <button
                  onClick={() => { setNameInput(profile?.display_name || ''); setEditingName(true); }}
                  className="flex items-center gap-1.5 text-[13px] text-teal hover:opacity-75 transition-opacity"
                >
                  <Pencil size={14} />
                  {profile?.display_name ? 'Edit' : 'Add name'}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Monthly income */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em]">Monthly income</p>
          </div>
          <div className="px-6 py-4">
            {editingIncome ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-[18px] font-sans text-slate font-medium">{profile?.currency_symbol || '£'}</span>
                  <input
                    type="number"
                    value={incomeInput}
                    onChange={(e) => setIncomeInput(e.target.value)}
                    placeholder="e.g. 3500"
                    autoFocus
                    min="0"
                    step="any"
                    onKeyDown={(e) => { if (e.key === 'Enter') handleSaveIncome(); if (e.key === 'Escape') setEditingIncome(false); }}
                    className="flex-1 font-sans text-[18px] font-semibold text-navy bg-page rounded-input px-3 py-2 border border-border outline-none focus:border-teal transition-colors"
                    style={{ fontVariantNumeric: 'tabular-nums' }}
                  />
                </div>
                <p className="text-[12px] text-muted font-sans">This is your base monthly salary. Additional income can be logged separately from the home screen.</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveIncome}
                    disabled={savingIncome || !incomeInput}
                    className="flex-1 h-10 bg-teal text-white rounded-btn text-[14px] font-semibold font-sans flex items-center justify-center gap-1.5 hover:bg-opacity-90 transition-all disabled:opacity-40"
                  >
                    {savingIncome ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check size={14} /> Save</>}
                  </button>
                  <button
                    onClick={() => setEditingIncome(false)}
                    className="h-10 px-4 border border-border rounded-btn text-[13px] text-muted hover:text-slate transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-sans font-semibold text-[18px] text-navy" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {profile?.monthly_income
                      ? formatAmount(profile.monthly_income, profile.currency_code || 'GBP')
                      : <span className="text-muted text-[15px] font-medium">Not set</span>}
                  </p>
                  <p className="text-[11px] text-muted font-sans mt-0.5">Base salary — added to any logged income entries</p>
                </div>
                <button
                  onClick={() => { setIncomeInput(profile?.monthly_income ? String(profile.monthly_income) : ''); setEditingIncome(true); }}
                  className="flex items-center gap-1.5 text-[13px] text-teal hover:opacity-75 transition-opacity"
                >
                  <Pencil size={14} />
                  {profile?.monthly_income ? 'Edit' : 'Set income'}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Your Goal */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em]">Your goal</p>
          </div>
          <div className="px-6 py-4 flex items-center justify-between">
            <p className="font-sans font-semibold text-[18px] text-navy">{goalLabel}</p>
            <button
              onClick={() => navigate('/onboarding/goal')}
              className="flex items-center gap-1 text-[13px] font-medium text-teal border-[1.5px] border-teal rounded-[10px] px-3 py-1.5 hover:bg-teal/5 transition-colors"
            >
              Change <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Currency */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em]">Currency</p>
          </div>
          <div className="px-6 py-4">
            {editingCurrency ? (
              <div className="space-y-3">
                <div className="space-y-2">
                  {CURRENCIES.map((c) => (
                    <button
                      key={c.code}
                      onClick={() => setSelectedCurrency(c.code)}
                      className={`w-full text-left px-4 py-3 rounded-btn border transition-all flex items-center justify-between ${
                        selectedCurrency === c.code
                          ? 'border-teal bg-teal/5 border-l-[3px]'
                          : 'border-border hover:border-slate/30'
                      }`}
                    >
                      <div>
                        <p className={`font-sans font-medium text-[14px] ${selectedCurrency === c.code ? 'text-navy' : 'text-slate'}`}>
                          {c.code} — {c.name}
                        </p>
                        <p className="font-sans text-[12px] text-muted">{c.symbol} · {c.example}</p>
                      </div>
                      {selectedCurrency === c.code && <Check size={15} className="text-teal shrink-0" />}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={handleSaveCurrency}
                    disabled={savingCurrency}
                    className="flex-1 h-10 bg-teal text-white rounded-btn text-[14px] font-semibold font-sans flex items-center justify-center gap-1.5 hover:bg-opacity-90 transition-all disabled:opacity-40"
                  >
                    {savingCurrency ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check size={14} /> Save</>}
                  </button>
                  <button
                    onClick={() => { setEditingCurrency(false); setSelectedCurrency(profile?.currency_code || 'GBP'); }}
                    className="h-10 px-4 border border-border rounded-btn text-[13px] text-muted hover:text-slate transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <p className="font-sans font-semibold text-[18px] text-navy">
                  {profile?.currency_code || 'GBP'} ({profile?.currency_symbol || '£'})
                </p>
                <button
                  onClick={() => { setSelectedCurrency(profile?.currency_code || 'GBP'); setEditingCurrency(true); }}
                  className="flex items-center gap-1 text-[13px] font-medium text-teal border-[1.5px] border-teal rounded-[10px] px-3 py-1.5 hover:bg-teal/5 transition-colors"
                >
                  Change <ChevronRight size={14} />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* End-of-month savings allocation */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="text-[11px] text-muted font-sans uppercase tracking-[0.12em]">End-of-month surplus</p>
          </div>
          <div className="px-6 py-4">
            {editingAllocation ? (
              <div className="space-y-3">
                {([
                  { value: 'apply_to_debt' as const, icon: TrendingDown, label: 'Apply to debt', sub: 'Surplus goes toward clearing what I owe' },
                  { value: 'keep_as_savings' as const, icon: PiggyBank, label: 'Keep as savings', sub: 'Build a buffer and grow my savings balance' },
                ] as const).map(({ value, icon: Icon, label, sub }) => (
                  <button
                    key={value}
                    onClick={() => setSelectedAllocation(value)}
                    className={`w-full text-left px-4 py-3 rounded-btn border transition-all flex items-center gap-3 ${
                      selectedAllocation === value
                        ? 'border-teal bg-teal/5 border-l-[3px]'
                        : 'border-border hover:border-slate/30'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-[8px] flex items-center justify-center shrink-0 ${selectedAllocation === value ? 'bg-teal/15' : 'bg-page'}`}>
                      <Icon size={15} className={selectedAllocation === value ? 'text-teal' : 'text-muted'} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-sans font-medium text-[14px] ${selectedAllocation === value ? 'text-navy' : 'text-slate'}`}>{label}</p>
                      <p className="font-sans text-[12px] text-muted">{sub}</p>
                    </div>
                    {selectedAllocation === value && <Check size={15} className="text-teal shrink-0" />}
                  </button>
                ))}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={handleSaveAllocation}
                    disabled={savingAllocation || !selectedAllocation}
                    className="flex-1 h-10 bg-teal text-white rounded-btn text-[14px] font-semibold font-sans flex items-center justify-center gap-1.5 hover:bg-opacity-90 transition-all disabled:opacity-40"
                  >
                    {savingAllocation ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check size={14} /> Save</>}
                  </button>
                  <button
                    onClick={() => { setEditingAllocation(false); setSelectedAllocation(profile?.savings_allocation ?? null); }}
                    className="h-10 px-4 border border-border rounded-btn text-[13px] text-muted hover:text-slate transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {profile?.savings_allocation ? (
                    <>
                      <div className="w-8 h-8 rounded-[8px] bg-teal/10 flex items-center justify-center">
                        {profile.savings_allocation === 'apply_to_debt'
                          ? <TrendingDown size={15} className="text-teal" />
                          : <PiggyBank size={15} className="text-teal" />}
                      </div>
                      <p className="font-sans font-medium text-[15px] text-slate">
                        {profile.savings_allocation === 'apply_to_debt' ? 'Apply to debt' : 'Keep as savings'}
                      </p>
                    </>
                  ) : (
                    <p className="font-sans font-medium text-[15px] text-muted">Not set</p>
                  )}
                </div>
                <button
                  onClick={() => { setSelectedAllocation(profile?.savings_allocation ?? null); setEditingAllocation(true); }}
                  className="flex items-center gap-1.5 text-[13px] text-teal hover:opacity-75 transition-opacity"
                >
                  <Pencil size={14} />
                  {profile?.savings_allocation ? 'Edit' : 'Set'}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Help */}
        <div className="bg-surface rounded-card shadow-card overflow-hidden">
          <button
            className="w-full px-6 py-4 flex items-center justify-between hover:bg-page/60 transition-colors"
            onClick={() => setShowHelp(true)}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-[8px] bg-teal/10 flex items-center justify-center">
                <HelpCircle size={16} className="text-teal" />
              </div>
              <div className="text-left">
                <p className="font-sans font-medium text-[15px] text-slate">Help & FAQ</p>
                <p className="font-sans text-[12px] text-muted">How the app works, income math, goals, and more</p>
              </div>
            </div>
            <ChevronRight size={16} className="text-muted" />
          </button>
        </div>

        {/* Sign out */}
        <div className="bg-surface rounded-card shadow-card p-6">
          <button
            onClick={handleSignOut}
            disabled={signingOut}
            className="w-full h-12 border-[1.5px] border-navy text-navy rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-navy/5 transition-colors disabled:opacity-50"
          >
            {signingOut ? (
              <span className="w-4 h-4 border-2 border-navy border-t-transparent rounded-full animate-spin" />
            ) : (
              <><LogOut size={18} /> Sign out</>
            )}
          </button>
        </div>

        <p className="text-center text-[12px] text-muted font-sans pt-4">
          Vera · Accelerator Hackathon 2026
        </p>
      </div>

      {/* Help modal */}
      {showHelp && (
        <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={() => setShowHelp(false)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-lg bg-surface rounded-t-[24px] shadow-2xl max-h-[90vh] flex flex-col animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-border" />
            </div>
            <div className="px-5 pt-2 pb-4 border-b border-border flex items-center justify-between">
              <div>
                <h2 className="font-heading font-semibold text-navy text-[18px]">Help & FAQ</h2>
                <p className="text-[12px] text-muted font-sans mt-0.5">Tap a question to expand</p>
              </div>
              <button onClick={() => setShowHelp(false)} className="p-2 rounded-btn text-muted hover:text-slate transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="overflow-y-auto flex-1">
              <HelpAccordion items={HELP_ITEMS} />
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
