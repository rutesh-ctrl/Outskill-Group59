import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';
import { CURRENCY_MULTIPLIERS } from '../../lib/types';
import { toISODateString } from '../../lib/currency';

interface SeedExpense {
  description: string;
  category: string;
  amount_gbp: number;
  is_essential: boolean;
  days_ago: number;
}

const SEED_EXPENSES: SeedExpense[] = [
  { description: 'Weekly grocery shop', category: 'Food & Drink', amount_gbp: 67.4, is_essential: true, days_ago: 6 },
  { description: 'Netflix subscription', category: 'Subscriptions', amount_gbp: 15.99, is_essential: false, days_ago: 5 },
  { description: 'Uber to work', category: 'Transport', amount_gbp: 14.0, is_essential: false, days_ago: 4 },
  { description: 'Lunch with colleague', category: 'Food & Drink', amount_gbp: 18.5, is_essential: false, days_ago: 3 },
  { description: 'Phone bill', category: 'Bills', amount_gbp: 35.0, is_essential: true, days_ago: 2 },
  { description: 'Takeaway dinner', category: 'Food & Drink', amount_gbp: 24.99, is_essential: false, days_ago: 1 },
];

export default function OnboardingComplete() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const setup = async () => {
      if (!user || !profile) return;
      try {
        const multiplier = CURRENCY_MULTIPLIERS[profile.currency_code] ?? 1;
        const today = new Date();

        const seedRows = SEED_EXPENSES.map((s) => {
          const date = new Date(today);
          date.setDate(today.getDate() - s.days_ago);
          return {
            user_id: user.id,
            amount: parseFloat((s.amount_gbp * multiplier).toFixed(2)),
            currency_code: profile.currency_code,
            description: s.description,
            category: s.category,
            is_essential: s.is_essential,
            is_seed: true,
            raw_input: s.description,
            ai_confidence: 1,
            micro_reaction: '',
            expense_date: toISODateString(date),
          };
        });

        const { error: insertError } = await supabase.from('expenses').insert(seedRows);
        if (insertError) throw insertError;

        const { error: updateError } = await supabase
          .from('user_profiles')
          .upsert({ user_id: user.id, onboarding_complete: true }, { onConflict: 'user_id' });
        if (updateError) throw updateError;

        await refreshProfile();
        setDone(true);

        setTimeout(() => navigate('/'), 2000);
      } catch {
        setError('Something went wrong during setup — please try again');
      }
    };

    setup();
  }, [user, profile]);

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className="h-1 w-8 rounded-full bg-teal" />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8 text-center">
          {!done && !error ? (
            <>
              <div className="flex justify-center mb-6">
                <div className="w-12 h-12 border-2 border-teal border-t-transparent rounded-full animate-spin" />
              </div>
              <h2 className="font-heading font-semibold text-navy text-[22px] mb-2">
                Setting things up...
              </h2>
              <p className="text-[14px] text-muted font-sans">
                Preparing your personalised experience.
              </p>
            </>
          ) : error ? (
            <>
              <p className="text-[14px] text-red font-sans mb-4">{error}</p>
              <button
                onClick={() => window.location.reload()}
                className="h-12 px-6 bg-teal text-white rounded-btn text-[15px] font-medium font-sans hover:bg-opacity-90 transition-all"
              >
                Try again
              </button>
            </>
          ) : (
            <>
              <div className="flex justify-center mb-6">
                <CheckCircle2 size={48} className="text-teal" />
              </div>
              <h2 className="font-heading font-semibold text-navy text-[28px] mb-3">
                You&apos;re all set.
              </h2>
              <p className="text-[14px] text-muted font-sans leading-relaxed mb-8">
                We&apos;ve added some example expenses so you can see Vera in action. Add your own anytime.
              </p>
              <button
                onClick={() => navigate('/dashboard')}
                className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all"
              >
                Go to my dashboard <ArrowRight size={16} />
              </button>
              <p className="mt-4 text-[12px] text-muted font-sans">
                Redirecting automatically...
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
