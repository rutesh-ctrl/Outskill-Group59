import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';
import { Goal, GOAL_LABELS, GOAL_SUBTEXTS, GOAL_TARGET_LABEL, GOAL_TARGET_PLACEHOLDER } from '../../lib/types';

const GOALS: Goal[] = ['save_more', 'spend_less', 'clear_debt'];

export default function OnboardingGoal() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const [selected, setSelected] = useState<Goal | null>(null);
  const [targetAmount, setTargetAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const targetLabel = selected ? GOAL_TARGET_LABEL[selected] : null;
  const targetPlaceholder = selected ? GOAL_TARGET_PLACEHOLDER[selected] : '';

  const handleContinue = async () => {
    if (!selected || !user) return;
    setLoading(true);
    setError('');
    try {
      // Save goal type to user_profiles (for backwards compat with AI mentor)
      const { error: profileError } = await supabase
        .from('user_profiles')
        .upsert({ user_id: user.id, goal: selected }, { onConflict: 'user_id' });
      if (profileError) throw profileError;

      // Save to user_goals table
      const amount = targetAmount ? parseFloat(targetAmount) : null;
      const { error: goalError } = await supabase.from('user_goals').insert({
        user_id: user.id,
        goal_type: selected,
        label: GOAL_LABELS[selected],
        target_amount: amount && !isNaN(amount) ? amount : null,
        current_amount: 0,
        is_active: true,
      });
      if (goalError) throw goalError;

      await refreshProfile();
      navigate('/onboarding/income');
    } catch {
      setError('Could not save your goal — please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all ${i === 1 ? 'w-8 bg-teal' : 'w-4 bg-border'}`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8">
          <h2 className="font-heading font-semibold text-navy text-[22px] mb-2 leading-snug">
            What's the one thing you want to change about your money?
          </h2>
          <p className="text-[14px] text-muted font-sans mb-6">
            Be honest — this shapes everything Vera tells you.
          </p>

          <div className="space-y-3 mb-6">
            {GOALS.map((g) => (
              <button
                key={g}
                onClick={() => { setSelected(g); setTargetAmount(''); }}
                className={`w-full text-left p-4 rounded-btn border transition-all ${
                  selected === g
                    ? 'border-teal bg-ai-bg border-l-[3px]'
                    : 'border-border bg-white hover:border-steel/40 hover:bg-page'
                }`}
              >
                <p className={`font-sans font-medium text-[15px] ${selected === g ? 'text-navy' : 'text-slate'}`}>
                  {GOAL_LABELS[g]}
                </p>
                <p className="font-sans text-[13px] text-muted mt-0.5">{GOAL_SUBTEXTS[g]}</p>
              </button>
            ))}
          </div>

          {/* Target amount — shown when a goal is selected and has a target */}
          {selected && targetLabel && (
            <div className="mb-6 p-4 bg-ai-bg rounded-btn border border-teal/20 space-y-3 animate-slide-up">
              <label className="block text-[13px] font-semibold text-navy font-sans">
                {targetLabel}
              </label>
              <input
                type="number"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                placeholder={targetPlaceholder}
                min="0"
                step="any"
                autoFocus
                className="w-full h-11 px-4 border border-border rounded-input text-[15px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              />
              <p className="text-[12px] text-muted font-sans">Optional — you can update this anytime from your home screen</p>
            </div>
          )}

          {error && <p className="text-[13px] text-red font-sans mb-4">{error}</p>}

          <button
            onClick={handleContinue}
            disabled={!selected || loading}
            className={`w-full h-12 rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 transition-all ${
              selected && !loading
                ? 'bg-teal text-white hover:bg-opacity-90'
                : 'bg-border text-muted cursor-not-allowed'
            }`}
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>This is my goal <ArrowRight size={16} /></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
