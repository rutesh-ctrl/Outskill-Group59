import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';
import { CURRENCIES } from '../../lib/types';
import { formatAmount } from '../../lib/currency';

export default function OnboardingCurrency() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const [selected, setSelected] = useState<string>('GBP');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleContinue = async () => {
    if (!user) return;
    const currency = CURRENCIES.find((c) => c.code === selected);
    if (!currency) return;

    setLoading(true);
    setError('');
    try {
      const { error: upsertError } = await supabase
        .from('user_profiles')
        .upsert(
          { user_id: user.id, currency_code: currency.code, currency_symbol: currency.symbol },
          { onConflict: 'user_id' }
        );
      if (upsertError) throw upsertError;
      await refreshProfile();
      navigate('/onboarding/allocation');
    } catch {
      setError('Could not save your currency — please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all ${i === 3 ? 'w-8 bg-teal' : i < 3 ? 'w-4 bg-teal/40' : 'w-4 bg-border'}`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8">
          <h2 className="font-heading font-semibold text-navy text-[22px] mb-2 leading-snug">
            Where are you based?
          </h2>
          <p className="text-[14px] text-muted font-sans mb-6">
            We'll format your money correctly.
          </p>

          <div className="space-y-3 mb-6">
            {CURRENCIES.map((c) => {
              const exampleAmount = c.code === 'INR' ? 124000 : 1240;
              return (
                <button
                  key={c.code}
                  onClick={() => setSelected(c.code)}
                  className={`w-full text-left p-4 rounded-btn border transition-all flex items-center justify-between ${
                    selected === c.code
                      ? 'border-teal bg-ai-bg border-l-[3px]'
                      : 'border-border bg-white hover:border-steel/40 hover:bg-page'
                  }`}
                >
                  <div>
                    <p className={`font-sans font-medium text-[15px] ${selected === c.code ? 'text-navy' : 'text-slate'}`}>
                      {c.code} — {c.name}
                    </p>
                    <p className="font-sans text-[13px] text-muted mt-0.5">{c.symbol}</p>
                  </div>
                  <span
                    className="font-sans text-[14px] text-muted tabular-nums"
                    style={{ fontVariantNumeric: 'tabular-nums' }}
                  >
                    {formatAmount(exampleAmount, c.code)}
                  </span>
                </button>
              );
            })}
          </div>

          {error && (
            <p className="text-[13px] text-red font-sans mb-4">{error}</p>
          )}

          <button
            onClick={handleContinue}
            disabled={loading}
            className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-50"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>Set my currency <ArrowRight size={16} /></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
