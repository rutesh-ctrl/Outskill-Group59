import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';

export default function OnboardingIncome() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const [income, setIncome] = useState('');
  const [outgoings, setOutgoings] = useState('');
  const [incomeError, setIncomeError] = useState('');
  const [outgoingsError, setOutgoingsError] = useState('');
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const incomeNum = parseFloat(income);
  const outgoingsNum = parseFloat(outgoings);
  const showAmberWarning =
    income && outgoings && !isNaN(incomeNum) && !isNaN(outgoingsNum) && outgoingsNum >= incomeNum;

  const validateIncome = () => {
    if (!income || isNaN(incomeNum) || incomeNum <= 0) {
      setIncomeError('Enter a valid monthly income greater than 0');
      return false;
    }
    setIncomeError('');
    return true;
  };

  const validateOutgoings = () => {
    if (!outgoings || isNaN(outgoingsNum) || outgoingsNum <= 0) {
      setOutgoingsError('Enter valid monthly outgoings greater than 0');
      return false;
    }
    setOutgoingsError('');
    return true;
  };

  const handleContinue = async () => {
    const incomeOk = validateIncome();
    const outgoingsOk = validateOutgoings();
    if (!incomeOk || !outgoingsOk || !user) return;

    setLoading(true);
    setFormError('');
    try {
      const { error } = await supabase
        .from('user_profiles')
        .upsert(
          { user_id: user.id, monthly_income: incomeNum, monthly_outgoings: outgoingsNum },
          { onConflict: 'user_id' }
        );
      if (error) throw error;
      await refreshProfile();
      navigate('/onboarding/currency');
    } catch {
      setFormError('Could not save your details — please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all ${i === 2 ? 'w-8 bg-teal' : i < 2 ? 'w-4 bg-teal/40' : 'w-4 bg-border'}`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8">
          <h2 className="font-heading font-semibold text-navy text-[22px] mb-2 leading-snug">
            Give us a rough picture
          </h2>
          <p className="text-[14px] text-muted font-sans mb-6">
            We won't share this. It helps Vera give advice that fits your life.
          </p>

          <div className="space-y-5 mb-6">
            <div>
              <label className="block text-[13px] font-medium text-slate mb-2">
                Monthly take-home pay (after tax)
              </label>
              <input
                type="number"
                value={income}
                onChange={(e) => setIncome(e.target.value)}
                onBlur={validateIncome}
                placeholder="e.g. 2400"
                min="0"
                step="any"
                className="w-full h-12 px-4 border border-border rounded-input text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              />
              {incomeError && <p className="mt-1.5 text-[13px] text-red font-sans">{incomeError}</p>}
            </div>

            <div>
              <label className="block text-[13px] font-medium text-slate mb-2">
                Rough monthly total outgoings
              </label>
              <input
                type="number"
                value={outgoings}
                onChange={(e) => setOutgoings(e.target.value)}
                onBlur={validateOutgoings}
                placeholder="e.g. 1800"
                min="0"
                step="any"
                className="w-full h-12 px-4 border border-border rounded-input text-[14px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
              />
              <p className="mt-1.5 text-[12px] text-muted font-sans">
                Outgoings = rent, bills, subscriptions, food, transport — your usual monthly spend.
              </p>
              {outgoingsError && <p className="mt-1 text-[13px] text-red font-sans">{outgoingsError}</p>}
            </div>
          </div>

          {showAmberWarning && (
            <div className="mb-5 p-4 bg-amber/10 border border-amber/30 rounded-btn flex gap-3">
              <AlertTriangle size={18} className="text-amber mt-0.5 shrink-0" />
              <p className="text-[13px] text-slate font-sans leading-relaxed">
                Looks like your outgoings meet or exceed your income — that&apos;s exactly what Vera can help with.
              </p>
            </div>
          )}

          {formError && (
            <p className="text-[13px] text-red font-sans mb-4">{formError}</p>
          )}

          <button
            onClick={handleContinue}
            disabled={loading}
            className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>Got it <ArrowRight size={16} /></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
