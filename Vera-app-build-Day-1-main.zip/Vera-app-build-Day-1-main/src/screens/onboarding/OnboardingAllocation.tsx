import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, PiggyBank, TrendingDown } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';

type Allocation = 'apply_to_debt' | 'keep_as_savings';

const OPTIONS: { value: Allocation; icon: typeof PiggyBank; title: string; description: string }[] = [
  {
    value: 'apply_to_debt',
    icon: TrendingDown,
    title: 'Apply it to my debt',
    description: 'Any money left over at the end of the month goes straight toward clearing what I owe.',
  },
  {
    value: 'keep_as_savings',
    icon: PiggyBank,
    title: 'Keep it as savings',
    description: "I'd rather build a buffer and grow my savings balance over time.",
  },
];

export default function OnboardingAllocation() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const [selected, setSelected] = useState<Allocation | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleContinue = async () => {
    if (!selected || !user) return;
    setLoading(true);
    setError('');
    try {
      const { error: dbError } = await supabase
        .from('user_profiles')
        .upsert({ user_id: user.id, savings_allocation: selected }, { onConflict: 'user_id' });
      if (dbError) throw dbError;
      await refreshProfile();
      navigate('/onboarding/complete');
    } catch {
      setError('Could not save your preference — please try again');
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = () => navigate('/onboarding/complete');

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all ${
                  i <= 3 ? 'w-4 bg-teal/40' : 'w-8 bg-teal'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8">
          <h2 className="font-heading font-semibold text-navy text-[22px] mb-2 leading-snug">
            When you have money left at the end of the month...
          </h2>
          <p className="text-[14px] text-muted font-sans mb-6">
            This helps Vera give you the right nudge when you're in surplus.
          </p>

          <div className="space-y-3 mb-6">
            {OPTIONS.map(({ value, icon: Icon, title, description }) => (
              <button
                key={value}
                onClick={() => setSelected(value)}
                className={`w-full text-left p-4 rounded-btn border transition-all flex items-start gap-4 ${
                  selected === value
                    ? 'border-teal bg-ai-bg border-l-[3px]'
                    : 'border-border bg-white hover:border-steel/40 hover:bg-page'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-[8px] flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                    selected === value ? 'bg-teal/15' : 'bg-page'
                  }`}
                >
                  <Icon
                    size={18}
                    className={selected === value ? 'text-teal' : 'text-muted'}
                  />
                </div>
                <div>
                  <p
                    className={`font-sans font-semibold text-[15px] mb-0.5 ${
                      selected === value ? 'text-navy' : 'text-slate'
                    }`}
                  >
                    {title}
                  </p>
                  <p className="font-sans text-[13px] text-muted leading-snug">{description}</p>
                </div>
              </button>
            ))}
          </div>

          {error && <p className="text-[13px] text-red font-sans mb-4">{error}</p>}

          <button
            onClick={handleContinue}
            disabled={!selected || loading}
            className={`w-full h-12 rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 transition-all ${
              selected && !loading
                ? 'bg-teal text-white hover:bg-opacity-90'
                : 'bg-border text-muted cursor-not-allowed'
            }`}
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>That's my plan <ArrowRight size={16} /></>
            )}
          </button>

          <button
            onClick={handleSkip}
            className="w-full mt-3 text-[13px] text-muted font-sans hover:text-slate transition-colors text-center py-1"
          >
            Skip for now
          </button>
        </div>
      </div>
    </div>
  );
}
