import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import VeraLogo from '../../components/VeraLogo';

export default function OnboardingName() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const oauthName = user?.user_metadata?.full_name || user?.user_metadata?.name || '';
  const [name, setName] = useState(oauthName);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleContinue = async () => {
    if (!user) return;
    setLoading(true);
    setError('');
    try {
      const { error: upsertError } = await supabase
        .from('user_profiles')
        .upsert(
          { user_id: user.id, display_name: name.trim() || null },
          { onConflict: 'user_id' }
        );
      if (upsertError) throw upsertError;
      await refreshProfile();
      navigate('/onboarding/goal');
    } catch {
      setError('Could not save — please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-page flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="flex justify-center mb-2">
          <VeraLogo size={120} />
        </div>
        <div className="flex justify-center mb-8">
          <div className="flex gap-1.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all ${i === 0 ? 'w-8 bg-teal' : 'w-4 bg-border'}`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-card shadow-card p-8">
          <h2 className="font-heading font-semibold text-navy text-[22px] mb-2 leading-snug">
            What should we call you?
          </h2>
          <p className="text-[14px] text-muted font-sans mb-6">
            Vera will use your first name to personalise your experience.
          </p>

          <div className="mb-6">
            <label className="block text-[13px] font-medium text-slate mb-2">
              First name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleContinue(); }}
              placeholder="e.g. Sarah"
              autoFocus
              className="w-full h-12 px-4 border border-border rounded-input text-[16px] font-sans text-slate bg-white focus:outline-none focus:ring-2 focus:ring-teal transition-shadow"
            />
          </div>

          {error && <p className="text-[13px] text-red font-sans mb-4">{error}</p>}

          <button
            onClick={handleContinue}
            disabled={loading}
            className="w-full h-12 bg-teal text-white rounded-btn text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-50"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>Continue <ArrowRight size={16} /></>
            )}
          </button>

          <button
            onClick={() => navigate('/onboarding/goal')}
            className="w-full mt-3 text-[13px] text-muted font-sans hover:text-slate transition-colors"
          >
            Skip for now
          </button>
        </div>
      </div>
    </div>
  );
}
