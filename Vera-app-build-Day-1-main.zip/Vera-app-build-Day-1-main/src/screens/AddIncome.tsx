import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { formatAmount, toISODateString } from '../lib/currency';
import BottomNav from '../components/BottomNav';
import VeraLogo from '../components/VeraLogo';

const INCOME_CATEGORIES = [
  'Salary',
  'Freelance',
  'Gift',
  'Investment',
  'Rental',
  'Benefits',
  'Other',
] as const;

type IncomeCategory = (typeof INCOME_CATEGORIES)[number];

export default function AddIncome() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const amountRef = useRef<HTMLInputElement>(null);

  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IncomeCategory>('Salary');
  const [date, setDate] = useState(toISODateString(new Date()));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    amountRef.current?.focus();
  }, []);

  const currencyCode = profile?.currency_code || 'GBP';
  const symbol = profile?.currency_symbol || '£';

  const handleSave = async () => {
    const parsed = parseFloat(amount);
    if (!user || isNaN(parsed) || parsed <= 0) {
      setError('Please enter a valid amount greater than zero.');
      return;
    }

    setSaving(true);
    setError('');

    const { error: insertError } = await supabase.from('income').insert({
      user_id: user.id,
      amount: parsed,
      currency_code: currencyCode,
      description: description.trim() || category,
      category,
      income_date: date,
    });

    if (insertError) {
      setError('Could not save — please try again.');
      setSaving(false);
      return;
    }

    setSaved(true);
    setTimeout(() => navigate('/'), 1200);
  };

  const amountNum = parseFloat(amount);
  const validAmount = !isNaN(amountNum) && amountNum > 0;

  return (
    <div className="min-h-screen bg-page flex flex-col pb-20">
      {/* Header */}
      <nav className="bg-surface border-b border-border sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-2">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-btn hover:bg-border/50 transition-colors text-navy mr-1"
          >
            <ArrowLeft size={20} />
          </button>
          <VeraLogo iconOnly size={48} className="shrink-0" />
          <h1 className="font-heading font-semibold text-navy text-[20px]">Add Income</h1>
        </div>
      </nav>

      <div className="flex-1 max-w-lg mx-auto w-full px-4 py-6 space-y-5">

        {/* Success state */}
        {saved && (
          <div className="bg-teal/10 border border-teal/20 rounded-card px-5 py-4 flex items-center gap-3 animate-slide-up">
            <div className="w-8 h-8 rounded-full bg-teal flex items-center justify-center shrink-0">
              <Check size={16} className="text-white" />
            </div>
            <div>
              <p className="font-sans font-semibold text-[14px] text-teal">Income logged!</p>
              <p className="font-sans text-[12px] text-muted mt-0.5">Redirecting you home...</p>
            </div>
          </div>
        )}

        {/* Amount */}
        <div className="bg-surface rounded-card shadow-card p-6">
          <label className="block text-[12px] text-muted font-sans uppercase tracking-wide mb-3">
            Amount
          </label>
          <div className="flex items-center gap-2">
            <span className="font-heading font-semibold text-navy text-[28px] leading-none">
              {symbol}
            </span>
            <input
              ref={amountRef}
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => { setAmount(e.target.value); setError(''); }}
              placeholder="0.00"
              min="0"
              step="any"
              className="flex-1 font-heading font-semibold text-navy text-[36px] leading-none bg-transparent outline-none placeholder:text-border"
              style={{ fontVariantNumeric: 'tabular-nums' }}
            />
          </div>
          {validAmount && (
            <p className="font-sans text-[13px] text-teal mt-3 font-medium">
              {formatAmount(amountNum, currencyCode)}
            </p>
          )}
        </div>

        {/* Description */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <label className="block text-[12px] text-muted font-sans uppercase tracking-wide mb-3">
            Description <span className="normal-case text-muted/60">(optional)</span>
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={`e.g. Monthly salary, Client payment...`}
            className="w-full text-[15px] font-sans text-slate bg-transparent outline-none placeholder:text-muted/50"
          />
        </div>

        {/* Category */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <label className="block text-[12px] text-muted font-sans uppercase tracking-wide mb-3">
            Category
          </label>
          <div className="flex flex-wrap gap-2">
            {INCOME_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-[13px] font-medium font-sans transition-all ${
                  category === cat
                    ? 'bg-teal text-white'
                    : 'bg-white text-slate border border-border hover:border-teal/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Date */}
        <div className="bg-surface rounded-card shadow-card p-5">
          <label className="block text-[12px] text-muted font-sans uppercase tracking-wide mb-3">
            Date
          </label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full text-[15px] font-sans text-slate bg-transparent outline-none"
          />
        </div>

        {error && (
          <p className="text-[13px] text-red font-sans px-1">{error}</p>
        )}

        {/* Save */}
        <button
          onClick={handleSave}
          disabled={saving || !validAmount || saved}
          className="w-full h-[52px] bg-teal text-white rounded-[12px] text-[15px] font-medium font-sans flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {saving ? (
            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <><Check size={16} /> Save income</>
          )}
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
