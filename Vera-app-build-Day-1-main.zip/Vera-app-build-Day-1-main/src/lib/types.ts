export type Goal = 'save_more' | 'spend_less' | 'clear_debt';

export type Category =
  | 'Food & Drink'
  | 'Transport'
  | 'Shopping'
  | 'Entertainment'
  | 'Health'
  | 'Subscriptions'
  | 'Bills'
  | 'Other';

export interface UserProfile {
  id: string;
  user_id: string;
  goal: Goal | '';
  monthly_income: number;
  monthly_outgoings: number;
  currency_code: string;
  currency_symbol: string;
  onboarding_complete: boolean;
  daily_budget: number | null;
  display_name: string | null;
  savings_goal_amount: number | null;
  savings_allocation: 'apply_to_debt' | 'keep_as_savings' | null;
  created_at: string;
}

export interface Expense {
  id: string;
  user_id: string;
  amount: number;
  currency_code: string;
  description: string;
  category: Category;
  is_essential: boolean;
  is_seed: boolean;
  raw_input: string;
  ai_confidence: number;
  micro_reaction: string;
  expense_date: string;
  created_at: string;
}

export interface UserGoal {
  id: string;
  user_id: string;
  goal_type: Goal | string;
  label: string;
  target_amount: number | null;
  current_amount: number;
  is_active: boolean;
  created_at: string;
}

export interface Income {
  id: string;
  user_id: string;
  amount: number;
  currency_code: string;
  description: string;
  category: string;
  income_date: string;
  created_at: string;
}

export interface AiSummary {
  id: string;
  user_id: string;
  summary_text: string;
  generated_at: string;
  week_start: string;
}

export const GOAL_LABELS: Record<Goal, string> = {
  save_more: 'Save more',
  spend_less: 'Spend less',
  clear_debt: 'Clear debt',
};

export const GOAL_SUBTEXTS: Record<Goal, string> = {
  save_more: 'I want to build a buffer or save for something specific',
  spend_less: "I know I'm wasting money — I just don't know where",
  clear_debt: 'I want to pay off what I owe and stop the cycle',
};

export const GOAL_TARGET_LABEL: Record<Goal, string | null> = {
  save_more: 'How much do you want to save?',
  spend_less: 'What is your target monthly spend?',
  clear_debt: 'Total debt amount to clear',
};

export const GOAL_TARGET_PLACEHOLDER: Record<Goal, string> = {
  save_more: 'e.g. 5000',
  spend_less: 'e.g. 1500',
  clear_debt: 'e.g. 8000',
};

export const CURRENCIES = [
  { code: 'GBP', name: 'British Pound', symbol: '£', example: '£1,240.00' },
  { code: 'USD', name: 'US Dollar', symbol: '$', example: '$1,240.00' },
  { code: 'EUR', name: 'Euro', symbol: '€', example: '€1,240.00' },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', example: '₹1,24,000.00' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', example: 'A$1,240.00' },
];

export const CURRENCY_MULTIPLIERS: Record<string, number> = {
  GBP: 1.0,
  USD: 1.26,
  EUR: 1.17,
  INR: 107.0,
  AUD: 1.93,
};

export const CATEGORIES: Category[] = [
  'Food & Drink',
  'Transport',
  'Shopping',
  'Entertainment',
  'Health',
  'Subscriptions',
  'Bills',
  'Other',
];

export const CATEGORY_COLORS: Record<Category, string> = {
  'Food & Drink': '#0D9B8A',
  Transport: '#22C997',
  Shopping: '#4A7FC1',
  Entertainment: '#F5A623',
  Health: '#E8495A',
  Subscriptions: '#0F2D5C',
  Bills: '#6B7A8D',
  Other: '#2D3A4A',
};
