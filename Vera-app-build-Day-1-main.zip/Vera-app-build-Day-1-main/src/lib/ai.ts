const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const callAI = async (
  systemPrompt: string,
  userMessage: string,
  maxTokens = 300,
  temperature = 0.4,
  image?: { base64: string; mimeType: string }
): Promise<string> => {
  const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-proxy`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({
      systemPrompt,
      userMessage,
      maxTokens,
      temperature,
      imageBase64: image?.base64,
      imageMimeType: image?.mimeType,
    }),
  });

  if (!response.ok) {
    throw new Error(`AI call failed: ${response.status}`);
  }

  const data = await response.json();
  if (data.error) throw new Error(data.error);
  return data.content;
};
