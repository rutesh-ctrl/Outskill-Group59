import { ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthScreen from './screens/AuthScreen';
import Home from './screens/Home';
import OnboardingName from './screens/onboarding/OnboardingName';
import OnboardingGoal from './screens/onboarding/OnboardingGoal';
import OnboardingIncome from './screens/onboarding/OnboardingIncome';
import OnboardingCurrency from './screens/onboarding/OnboardingCurrency';
import OnboardingAllocation from './screens/onboarding/OnboardingAllocation';
import OnboardingComplete from './screens/onboarding/OnboardingComplete';
import Dashboard from './screens/Dashboard';
import AddExpense from './screens/AddExpense';
import AddIncome from './screens/AddIncome';
import Settings from './screens/Settings';
import Learn from './screens/Learn';
import DebtPayment from './screens/DebtPayment';

function RouteGuard({ children }: { children: ReactNode }) {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-page flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-teal border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  const isOnboarding = location.pathname.startsWith('/onboarding');

  if (!profile || !profile.onboarding_complete) {
    if (!isOnboarding) {
      return <Navigate to="/onboarding/name" replace />;
    }
  } else if (isOnboarding) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  const { user, loading, profile } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-page flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-teal border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/auth" element={user ? <Navigate to={(!profile || !profile.onboarding_complete) ? '/onboarding/name' : '/'} replace /> : <AuthScreen />} />
      <Route path="/onboarding/name" element={<RouteGuard><OnboardingName /></RouteGuard>} />
      <Route path="/onboarding/goal" element={<RouteGuard><OnboardingGoal /></RouteGuard>} />
      <Route path="/onboarding/income" element={<RouteGuard><OnboardingIncome /></RouteGuard>} />
      <Route path="/onboarding/currency" element={<RouteGuard><OnboardingCurrency /></RouteGuard>} />
      <Route path="/onboarding/allocation" element={<RouteGuard><OnboardingAllocation /></RouteGuard>} />
      <Route path="/onboarding/complete" element={<RouteGuard><OnboardingComplete /></RouteGuard>} />
      <Route path="/" element={<RouteGuard><Home /></RouteGuard>} />
      <Route path="/dashboard" element={<RouteGuard><Dashboard /></RouteGuard>} />
      <Route path="/add" element={<RouteGuard><AddExpense /></RouteGuard>} />
      <Route path="/income" element={<RouteGuard><AddIncome /></RouteGuard>} />
      <Route path="/debt-payment" element={<RouteGuard><DebtPayment /></RouteGuard>} />
      <Route path="/settings" element={<RouteGuard><Settings /></RouteGuard>} />
      <Route path="/learn" element={<RouteGuard><Learn /></RouteGuard>} />
      <Route path="*" element={<Navigate to="/auth" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
