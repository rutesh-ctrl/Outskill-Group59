/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        heading: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        page: '#F8F9FC',
        surface: '#FFFFFF',
        navy: '#0F2D5C',
        teal: '#0D9B8A',
        emerald: '#22C997',
        slate: '#2D3A4A',
        muted: '#6B7A8D',
        border: '#E4E8EF',
        amber: '#F5A623',
        steel: '#4A7FC1',
        red: '#E8495A',
        'ai-bg': '#EAF7F5',
      },
      borderRadius: {
        card: '16px',
        btn: '10px',
        input: '10px',
      },
      boxShadow: {
        card: '0 2px 12px rgba(15,45,92,0.07)',
      },
    },
  },
  plugins: [],
};
